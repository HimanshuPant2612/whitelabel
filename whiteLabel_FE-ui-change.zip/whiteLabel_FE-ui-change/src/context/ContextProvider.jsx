import React, { useEffect, createContext, useState } from "react";
const CreateContext = createContext();

const ContextProvider = ({ children }) => {
  const [superToken, setSuperToken] = useState(() => {
    const storedToken = localStorage.getItem("AuthToken");
    return storedToken ? storedToken : null;
  });

  useEffect(() => {
    const storedToken = localStorage.getItem("AuthToken");
    if (superToken === null && storedToken !== null) {
      setSuperToken(storedToken);
    }
  }, []);
  return (
    <CreateContext.Provider value={{ superToken, setSuperToken }}>
      {children}
    </CreateContext.Provider>
  );
};
export { CreateContext, ContextProvider };
