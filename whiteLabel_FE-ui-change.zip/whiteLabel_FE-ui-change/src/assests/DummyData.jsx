export const dummyContacts = [
  {
    contact: {
      phone: "1234567890",
      contactPerson: "shawn",
    },
    region: {
      name: "Chandigarh",
      countryCode: "IN",
      stateCode: "CH",
      lat: 434454324,
      long: -34543344,
    },
    orgLogo: {
      orgLogoUrl:
        "https://res.cloudinary.com/dizfnx5xy/image/upload/v1716188728/Org_Logos/n8orwmmmid8zonjyef7v.png",
      orgLogoPublicId: "Org_Logos/n8orwmmmid8zonjyef7v",
    },
    theme: {
      Primary: "#007bff",
      Secondary: "#6c757d",
      Accent: "#28a745",
    },
    _id: "664af639f93255dc3139bf41",
    orgName: "test organization",
    orgMail: "damaxa1617@lucvu.com",
    orgRegistrationDetails: "Registered in New York, USA",
    __v: 0,
    accessToken:
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJvcmdhbml6YXRpb25JZCI6IjY2NGFmNjM5ZjkzMjU1ZGMzMTM5YmY0MSIsIm9yZ19rZXkiOiIkMmIkMTAkSEh4bnNxLjNCNnpnUW9La1QuRnBhZUY5MXhIOEI4b0pCNUxaZTU4U1d1cUFnTjNFTTlMWmUiLCJpYXQiOjE3MTYxODkwMzQsImV4cCI6MTcxNjc5MzgzNH0.70H64k-FRtRPggymmXh_ZglUIF8cILQKInvPYdHGnbA",
  },
  {
    contact: {
      phone: "1234567890",
      contactPerson: "shawn",
    },
    region: {
      name: "Chandigarh",
      countryCode: "IN",
      stateCode: "CH",
      lat: 434454324,
      long: -34543344,
    },
    orgLogo: {
      orgLogoUrl:
        "https://res.cloudinary.com/dizfnx5xy/image/upload/v1716191021/Org_Logos/arjhdadqhdf8g4rr6bbk.png",
      orgLogoPublicId: "Org_Logos/arjhdadqhdf8g4rr6bbk",
    },
    theme: {
      Primary: "#007bff",
      Secondary: "#6c757d",
      Accent: "#28a745",
    },
    _id: "664aff2df93255dc3139bf50",
    orgName: "test organization",
    orgMail: "damaxa161@lucv.com",
    orgRegistrationDetails: "Registered in New York, USA",
    __v: 0,
    accessToken:
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJvcmdhbml6YXRpb25JZCI6IjY2NGFmZjJkZjkzMjU1ZGMzMTM5YmY1MCIsIm9yZ19rZXkiOiIkMmIkMTAkUjBMUHY1MGcvU1A1M2NBcHNNZDVYZWxPL2JiNlNDSFI2NmlYY1Vhb0FzWlJseVpkem42RGkiLCJpYXQiOjE3MTYxOTExMDAsImV4cCI6MTcxNjc5NTkwMH0.W6bVHVAQhPFmONh3bVK_Py3yFC8Pm_IuE04d4nE88wY",
  },
  {
    contact: {
      phone: "1234567890",
      contactPerson: "shawn",
    },
    region: {
      name: "Chandigarh",
      countryCode: "IN",
      stateCode: "CH",
      lat: 434454324,
      long: -34543344,
    },
    orgLogo: {
      orgLogoUrl:
        "https://res.cloudinary.com/dizfnx5xy/image/upload/v1716206909/Org_Logos/iahxjfdrgmlpycyopws5.png",
      orgLogoPublicId: "Org_Logos/iahxjfdrgmlpycyopws5",
    },
    theme: {
      Primary: "#007bff",
      Secondary: "#6c757d",
      Accent: "#28a745",
    },
    _id: "664b3d3ee77abf591bf27931",
    orgName: "technogetic pvt.",
    orgMail: "damaxa162@luc.comdfd",
    orgRegistrationDetails: "Registered in New York, USA",
    __v: 0,
  },
  {
    contact: {
      phone: "2445434532",
      contactPerson: "john",
    },
    region: {
      name: "Ingenio La Esperanza",
      countryCode: "AR",
      stateCode: "Y",
      latitude: -24.22554,
      longitude: -64.83896,
    },
    orgLogo: {
      orgLogoUrl:
        "https://res.cloudinary.com/dizfnx5xy/image/upload/v1716273245/Org_Logos/sffhjqotgob7fafdmv6f.png",
      orgLogoPublicId: "Org_Logos/sffhjqotgob7fafdmv6f",
    },
    theme: {
      primary: "#00c26a",
      secondary: "#48a631",
      accent: "#e212bd",
    },
    _id: "664c405de91b73a6da481f2e",
    orgName: "test organization",
    orgMail: "vokivo4574@qiradio.com",
    orgRegistrationDetails: "vdc c kdc sd dksv",
    __v: 0,
  },
  {
    contact: {
      phone: "09548592627",
      contactPerson: "kamal",
    },
    region: {
      name: "Baksa",
      countryCode: "IN",
      stateCode: "AS",
      latitude: 26.69804,
      longitude: 91.15142,
    },
    orgLogo: {
      orgLogoUrl:
        "https://res.cloudinary.com/dizfnx5xy/image/upload/v1716275334/Org_Logos/pl3hdhu07iw3vlhsrzqt.png",
      orgLogoPublicId: "Org_Logos/pl3hdhu07iw3vlhsrzqt",
    },
    theme: {
      primary: "#172a22",
      secondary: "#0e8a52",
      accent: "#57b98d",
    },
    _id: "664c4887e91b73a6da481f31",
    orgName: "technogetic",
    orgMail: "kamal.joshi@technogetic.com",
    orgRegistrationDetails: "dfsfdf",
    __v: 0,
  },
  {
    contact: {
      phone: "09548592627",
      contactPerson: "Rakesh",
    },
    region: {
      name: "Chetwayi",
      countryCode: "IN",
      stateCode: "KL",
      latitude: 10.52885,
      longitude: 76.04793,
    },
    orgLogo: {
      orgLogoUrl:
        "https://res.cloudinary.com/dizfnx5xy/image/upload/v1716278166/Org_Logos/bcunuyoed9tgyqksrzhn.png",
      orgLogoPublicId: "Org_Logos/bcunuyoed9tgyqksrzhn",
    },
    theme: {
      primary: "#1e2d26",
      secondary: "#006034",
      accent: "#919a96",
    },
    _id: "664c5397e91b73a6da481f35",
    orgName: "technogetic",
    orgMail: "rakesh@technogetic.com",
    orgRegistrationDetails: "dsfsfdf",
    __v: 0,
  },
];
