import React, { useState, useEffect, useContext } from "react";
import { Flex, HStack, useBreakpointValue, Box } from "@chakra-ui/react";
import { Outlet, useNavigate } from "react-router-dom";
import SideBar from "./components/SideBar";
import "./App.css";
import { CreateContext } from "./context/ContextProvider";

function App() {
  const { superToken, setSuperToken } = useContext(CreateContext);
  const navigate = useNavigate();
  const isMobile = useBreakpointValue({ base: true, md: false });

  const [alert, setAlert] = useState(null);

  useEffect(() => {
    const lastVisitedUrl = localStorage.getItem("lastVisitedUrl");
    if (lastVisitedUrl) {
      navigate(lastVisitedUrl);
    }
  }, [navigate]);

  return (
    <React.Fragment>
      <HStack w="full" h="100vh" bg="gray.100" padding={0}>
        {superToken && !isMobile && (
          <Flex
            // as="aside"
            // w="full"
            // h="100%"
            // maxW={250}
            // bg=""
            // alignItems="center"
            // padding={4}
            // flexDirection="column"
          >
            <SideBar setAlert={setAlert} />
          </Flex>
        )}
        <Flex
          as="main"
          w="full"
          h="100%"
          bg=""
          alignItems="center"
          flexDirection="column"
          justifyContent="space-between"
          position="relative"
          overflowX="hidden"
        >
          {superToken && isMobile && (
            <Box position="absolute" top={4} left={1} zIndex={1000}>
              <SideBar setAlert={setAlert} />
            </Box>
          )}
          {alert && alert}
          <Outlet context={{ setAlert }} />
        </Flex>
      </HStack>
    </React.Fragment>
  );
}
export default App;
