import { useEffect, useContext } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { CreateContext } from "../context/ContextProvider";

const useAxios = (handleAlert) => {
  const { superToken } = useContext(CreateContext);

  const instance = axios.create({
    baseURL: process.env.REACT_APP_BASE_URL,
  });
  const navigate = useNavigate();

  const getToken = () => {
    const authToken = superToken;
    return authToken;
  };

  // Add a request interceptor to include the token in the request headers
  instance.interceptors.request.use(
    async (config) => {
      try {
        const authToken = await getToken();

        if (authToken) {
          config.headers.Authorization = `Bearer ${authToken}`;
        }
      } catch (error) {
        handleAlert("error", error);
      }
      return config;
    },
    (error) => {
      return Promise.reject(error);
    }
  );

  // Add a response interceptor to handle 401 errors
  instance.interceptors.response.use(
    (response) => {
      return response;
    },
    (error) => {
      if (error.response && error.response.status === 401) {
        navigate("/");
        // Redirect to login page or handle reauthentication
      }
      return Promise.reject(error);
    }
  );

  useEffect(() => {
    // Empty useEffect to satisfy the ESLint dependency rule
  }, [navigate]);

  return instance;
};

export default useAxios;
