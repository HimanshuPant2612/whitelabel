import useAxios from "./Axios";

const RetreveOrgAPI = (handleAlert) => {
  const axiosInstance = useAxios(handleAlert);
  const allOrg = async ({ currentPage, contactsPerPage ,searchQuery=""}) => {
    try {
      const response = await axiosInstance.get(
        `/organizations?page=${currentPage}&perPage=${contactsPerPage}&search=${searchQuery}`
      );
      return response?.data;
    } catch (error) {
      const errorMessage =
        error?.response?.data?.message || "Error on Getting Organization Data";
      handleAlert("error", errorMessage);
    }
  };

  return allOrg;
};
export default RetreveOrgAPI;
