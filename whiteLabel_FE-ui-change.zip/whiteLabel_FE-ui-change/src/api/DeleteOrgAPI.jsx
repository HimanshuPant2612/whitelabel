import { useEffect } from "react";
import useAxios from "./Axios";

const useDeleteOrgAPI = (setAlert) => {
  const axiosInstance = useAxios(setAlert);

  const deleteOrg = async (postId) => {
    // const axiosInstance = useAxios(setAlert);
    try {
      const response = await axiosInstance.delete(`/organizations/${postId}`);
      setAlert("success", response.data.message);
    } catch (error) {
      if (
        error.response &&
        error.response.data &&
        error.response.data.message
      ) {
        setAlert("error", error.response.data.message);
      } else {
        setAlert("error", "Error on Getting Organizations");
      }
    }
  };

  useEffect(() => {}, []);

  return deleteOrg;
};

export default useDeleteOrgAPI;
