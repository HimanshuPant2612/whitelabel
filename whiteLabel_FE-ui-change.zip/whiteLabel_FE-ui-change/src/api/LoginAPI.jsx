import useAxios from "./Axios";

const LoginAPI = (handleAlert) => {
  const axiosInstance = useAxios(handleAlert);

  const loginUser = async ({ values, setLoading, setSuperToken }) => {
    try {
      const response = await axiosInstance.post("/login", values);
      if (!response?.data?.superToken) {
        handleAlert("error", "Error 401: Invalid Token");
      } else {
        localStorage.setItem("AuthToken", response?.data?.superToken);
        setSuperToken(response?.data?.superToken);
        handleAlert("success", "Login Successfuly");
        localStorage.setItem("lastVisitedUrl", window.location.pathname);
      }
    } catch (error) {
      const errorMessage =
        error.response?.data?.message ||
        "Error on Getting single Organization Data";
      handleAlert("error", errorMessage);
    } finally {
      setLoading(false);
    }
  };
  return loginUser;
};
export default LoginAPI;

// src/api/LoginAPI.jsx
// import useAxios from "./Axios";
// const LoginAPI = (handleAlert) => {
//   const axiosInstance = useAxios(handleAlert);

//   const loginUser = async ({ values, setLoading, setSuperToken }) => {
//     try {
//       // Use mock data instead of real API for now
//       const mockUsername = "admin";
//       const mockPassword = "12345";

//       // Simulate network delay for loading effect
//       await new Promise((resolve) => setTimeout(resolve, 1000));

//       if (values.username === mockUsername && values.key === mockPassword) {
//         const mockSuperToken = "mock-super-token-123456";

//         // Save the token
//         localStorage.setItem("AuthToken", mockSuperToken);
//         setSuperToken(mockSuperToken);
//         handleAlert("success", "Login Successfully");

//         // Save last visited URL for redirect after login
//         localStorage.setItem("lastVisitedUrl", "/Organizations");
//       } else {
//         // Simulate authentication failure
//         handleAlert("error", "Error 401: Invalid Credentials");
//       }
//     } catch (error) {
//       const errorMessage =
//         error.response?.data?.message ||
//         "Error on Getting single Organization Data";
//       handleAlert("error", errorMessage);
//     } finally {
//       setLoading(false);
//     }
//   };

//   return loginUser;
// };

// export default LoginAPI;
