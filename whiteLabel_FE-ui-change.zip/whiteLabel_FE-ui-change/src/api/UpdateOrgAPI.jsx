import { useEffect } from "react";
import useAxios from "./Axios";

const appendFormData = (formData, key, data) => {
  if (data instanceof File) {
    formData.append(key, data);
  } else if (
    data &&
    typeof data === "object" &&
    !(data instanceof Date) &&
    !(data instanceof Array)
  ) {
    for (const nestedKey in data) {
      if (nestedKey === "longitude") {
        appendFormData(
          formData,
          `${key}[longitude]`,
          data[nestedKey] ? parseFloat(data[nestedKey]) : 0
        );
      } else if (nestedKey === "latitude") {
        appendFormData(
          formData,
          `${key}[latitude]`,
          data[nestedKey] ? parseFloat(data[nestedKey]) : 0
        );
      } else appendFormData(formData, `${key}[${nestedKey}]`, data[nestedKey]);
    }
  } else if (data === null) {
    return;
  } else {
    formData.append(key, data);
  }
};
const useUpdateDetails = (setAlert) => {
  const axiosInstance = useAxios(setAlert);

  const UpdateOrganization = async (credentials, postId) => {
    try {
      const formData = new FormData();
      for (const key in credentials) {
        appendFormData(formData, key, credentials[key]);
      }
      const response = await axiosInstance.put(
        `/organizations/${postId}`,
        formData
      );
      setAlert("success", response?.data?.message);
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || "Error on Updating Organization";
      setAlert("error", errorMessage);
    }
  };
  useEffect(() => {}, []);

  return UpdateOrganization;
};

export default useUpdateDetails;
