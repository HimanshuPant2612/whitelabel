import useAxios from "./Axios";

const SingleOrgAPI = (handleAlert) => {
  const axiosInstance = useAxios(handleAlert);

  const SingleOrg = async ({ orgId, setContact, setLoading }) => {
    try {
      const response = await axiosInstance.get(`/organizations/${orgId}`);
      if (Object.keys(response?.data).length > 0) {
        setContact(response.data);
      } else {
        handleAlert("error", "Error 401: Invalid data format");
      }
    } catch (error) {
      const errorMessage =
        error.response?.data?.message ||
        "Error on Getting single Organization Data";
      handleAlert("error", errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return SingleOrg;
};
export default SingleOrgAPI;
