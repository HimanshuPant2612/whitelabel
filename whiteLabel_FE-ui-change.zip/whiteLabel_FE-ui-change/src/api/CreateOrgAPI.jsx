import { useEffect } from "react";
import useAxios from "./Axios";

export const appendFormData = (formData, key, data) => {
  if (data instanceof File) {
    formData.append(key, data);
  } else if (
    data &&
    typeof data === "object" &&
    !(data instanceof Date) &&
    !(data instanceof Array)
  ) {
    for (const nestedKey in data) {
      appendFormData(formData, `${key}[${nestedKey}]`, data[nestedKey]);
    }
  } else {
    formData.append(key, data);
  }
};
const useCreateOrg = (setAlert) => {
  const axiosInstance = useAxios(setAlert);

  const CreateOrg = async (credentials) => {
    try {
      const formData = new FormData();
      for (const key in credentials) {
        appendFormData(formData, key, credentials[key]);
      }
      const response = await axiosInstance.post("/organizations", formData);
      setAlert("success", response?.data?.message);
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || "Error on Updating Organization";
      setAlert("error", errorMessage);
    }
  };

  useEffect(() => {}, []);

  return CreateOrg;
};

export default useCreateOrg;
