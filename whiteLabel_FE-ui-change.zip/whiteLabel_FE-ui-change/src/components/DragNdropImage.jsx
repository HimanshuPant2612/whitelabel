import React, { useState } from "react";
import { AiOutlineCheckCircle, AiOutlineCloudUpload } from "react-icons/ai";
import { MdClear } from "react-icons/md";
import {
  Box,
  Stack,
  Flex,
  Text,
  Icon,
  FormLabel,
  Image,
} from "@chakra-ui/react";
import "./DragNdropImage.css";

const DragNdropImage = ({ onFilesSelected }) => {
  const [files, setFiles] = useState(null);

  const handleFileChange = (event) => {
    const selectedFiles = event.target.files[0];
    if (selectedFiles) {
      setFiles(selectedFiles);
      onFilesSelected(selectedFiles);
    }
  };
  const handleDrop = (event) => {
    event.preventDefault();
    const droppedFiles = event.dataTransfer.files[0];

    if (droppedFiles) {
      setFiles(droppedFiles);

      onFilesSelected(droppedFiles);
    }
  };

  const handleRemoveFile = () => {
    setFiles(null);
    onFilesSelected(null);
  };

  return (
    <Box maxW="sm" borderWidth="1px" borderRadius="lg" overflow="hidden">
      <div
        className={`document-uploader ${
          files ? "upload-box active" : "upload-box"
        }`}
        onDrop={handleDrop}
      >
        <Stack direction="row" p={0}>
          {files ? (
            <>
              <Stack>
                <Box m={2}>
                  <Flex mb={5} justifyContent="space-between">
                    <Flex>
                      <Icon
                        as={AiOutlineCheckCircle}
                        color="green.500"
                        boxSize={6}
                        mr={2}
                      />

                      <Text as="b" color="green.500">
                        selected
                      </Text>
                    </Flex>
                    <Icon
                      as={MdClear}
                      color="blue.200"
                      boxSize={6}
                      onClick={handleRemoveFile}
                      _hover={{ color: "red.500", cursor: "pointer" }}
                    />
                  </Flex>
                  <Image src={URL.createObjectURL(files)} alt="Logo" />
                </Box>
              </Stack>
            </>
          ) : (
            <Flex>
              <Icon
                as={AiOutlineCloudUpload}
                color="blue.900"
                boxSize={6}
                mr={2}
              />
              <input
                type="file"
                hidden
                id="browse"
                onChange={handleFileChange}
                // accept=".pdf,.docx,.pptx,.txt,.xlsx"
              />
              <FormLabel htmlFor="browse" m={0}>
                Browse files
              </FormLabel>
            </Flex>
          )}
        </Stack>
      </div>
    </Box>
  );
};

export default DragNdropImage;
