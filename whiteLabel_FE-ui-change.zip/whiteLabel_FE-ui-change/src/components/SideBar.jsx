import React, { useContext } from "react";
import { Flex, Box, Image, Icon, Button, VStack, useBreakpointValue, Drawer, DrawerOverlay, DrawerContent, DrawerCloseButton, DrawerBody } from "@chakra-ui/react";
import TGLogo from "../assests/TGLogo.png";
import { NavLink } from "react-router-dom";
import { MdDashboardCustomize, MdWorkspacesFilled, MdMenu } from "react-icons/md";
import CustomAlert from "../components/CustomAlert";
import { CreateContext } from "../context/ContextProvider";
import logout from '../assests/logout.svg';

const navLinks = [
  { to: "/", text: "Dashboard", icon: MdDashboardCustomize },
  { to: "/Organizations", text: "Organizational", icon: MdWorkspacesFilled },
];

const SideBar = ({ setAlert }) => {
  const { superToken, setSuperToken } = useContext(CreateContext);
  const isMobile = useBreakpointValue({ base: true, md: false });
  const [drawerOpen, setDrawerOpen] = React.useState(false);

  const handleLogout = () => {
    // removeAutToken();
    setSuperToken(null);
    localStorage.removeItem("AuthToken");
    localStorage.removeItem("lastVisitedUrl");
    setAlert(
      <CustomAlert
        status="success"
        alertmessage="Log Out Successfully"
        onTimeout={handleAlertTimeout}
      />
    );
  };
  const handleAlertTimeout = () => {
    setAlert(null);
  };
  const NavLinks = () => (
    <VStack spacing={2} align="stretch" w="full" mt={8}>
      {navLinks.map((link, index) => (
        <NavLink
          key={index}
          to={link.to}
          style={({ isActive }) => ({
            display: "flex",
            alignItems: "center",
            // borderRadius: "20px",
            padding: "8px 16px",
            fontWeight: 500,
          color: isActive ? "#1976d2" : "#6b7280",
          background: isActive ? "none" : "none",
            marginBottom: "6px",
            textDecoration: "none",
            borderRight: isActive ? "4px solid #1976d2": "none",
            gap: 12,
          })}
          onClick={() => isMobile && setDrawerOpen(false)}
        >
          <Icon as={link.icon} boxSize={5} mr={2} />
          {link.text}
        </NavLink>
      ))}
    </VStack>
  );
  // Mobile Drawer
  if (isMobile) {
    return (
      <>
        {/* Top bar with logo and menu on right */}
        <Flex
          as="nav"
          position="fixed"
          top={0}
          left={0}
          right={0}
          h="60px"
          bg="white"
          boxShadow="sm"
          zIndex={1500}
          px={4}
          alignItems="center"
          justifyContent="flex-end"
        >
          <Flex alignItems="center" justifyContent="space-between" w="full">
  <Image src={TGLogo} h="36px" objectFit="contain" />
  <Button
    onClick={() => setDrawerOpen(true)}
    variant="ghost"
    color="black"
    size="sm"
    borderRadius="none"
    p={1}
    _hover={{ bg: "gray.100" }}
    _active={{ bg: "gray.200" }}
  >
    <Icon as={MdMenu} boxSize={6} />
  </Button>
</Flex>

        </Flex>
        <Drawer isOpen={drawerOpen} placement="left" onClose={() => setDrawerOpen(false)}>
          <DrawerOverlay />
          <DrawerContent maxW="220px" bg="white">
            <DrawerCloseButton />
            <DrawerBody p={0}>
              <Flex direction="column" h="100vh" justifyContent="space-between">
                <Box>
                  <Box p={6} pb={2} borderBottom="1px solid #f0f0f0">
                    <Image src={TGLogo} w="100%" h="50px" objectFit="contain" />
                  </Box>
                  <NavLinks />
                </Box>
                <Box p={4} 
                // borderTop="1px solid #f0f0f0"
                >
                  {superToken && (
                    <Button colorScheme="red" variant="outline" w="full" onClick={handleLogout} leftIcon={<Image src={logout} boxSize={4} alt="Logout Icon" />}>
                      Logout
                    </Button>
                  )}
                </Box>
              </Flex>
            </DrawerBody>
          </DrawerContent>
        </Drawer>
        {/* Spacer for content below navbar */}
        <Box h="60px" />
      </>
    );
  }
  // Desktop Sidebar
  return (
    <Box
      bg="white"
      h="full"
      minH="100vh"
      w="220px"
      boxShadow="md"
      display="flex"
      flexDirection="column"
      justifyContent="space-between"
      p={0}
    >
      <Box>
        <Box p={6} pb={2} borderBottom="1px solid #f0f0f0">
          <Image src={TGLogo} w="100%" h="50px" objectFit="contain" />
        </Box>
        <NavLinks />
      </Box>
      <Box p={4} 
      >
        {superToken && (
          <Button colorScheme="red" variant="outline" w="full" onClick={handleLogout} leftIcon={<Image src={logout} boxSize={4} alt="Logout Icon" />}>
            Logout
          </Button>
        )}
      </Box>
    </Box>
  );
};
export default SideBar;