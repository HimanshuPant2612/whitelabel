import React from "react";
import { Box, Text, Flex, Image, VStack } from "@chakra-ui/react";

const SearchPopup = ({ results }) => {
  if (!results || results.length === 0) return null;

  return (
    <Box
      w="400px"
      maxH="288px"
      bg="white"
      rounded="10px"
      shadow="lg"
      border="1px solid rgba(0, 0, 0, 0.2)"
      overflowY="auto"
      position="absolute"
      zIndex="10"
      mt="6"
    >
      <Text pl={5} pt={3} fontSize="lg" fontWeight="medium" color="gray.700">
        Results
      </Text>
      <Box h="1px" bg="skyblue" mx="1" my={2} />
      <VStack align="start" spacing={4} px={5} pb={4}>
        {results.map((org) => (
          <Box key={org._id} w="full">
            <Flex align="center" gap={3}>
              <Box w="28px" h="28px" bg="gray.100" rounded="full" overflow="hidden">
                <Image
                  src={org?.orgLogo?.orgLogoUrl || "https://placehold.co/28x28"}
                  alt="Logo"
                  w="100%"
                  h="100%"
                  objectFit="cover"
                />
              </Box>
              <Text fontWeight="medium" fontSize="md" color="gray.700">
                {org.orgName}
              </Text>
            </Flex>
            <Text fontSize="sm" color="gray.600" ml="9">
              {org?.orgMail || "No Email"}
            </Text>
            <Box h="1px" bg="blackAlpha.100" my={2} />
          </Box>
        ))}
      </VStack>
    </Box>
  );
};

export default SearchPopup;
