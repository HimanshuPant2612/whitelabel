import { useState } from "react";
import { useNavigate, useOutletContext } from "react-router-dom";
import {
  Spinner,
  Select,
  Input,
  Center,
  Textarea,
  Stack,
  Box,
  Flex,
  FormLabel,
  FormControl,
  FormErrorMessage,
  Button,
  Text,
} from "@chakra-ui/react";
import { Formik } from "formik";
import ThemeColorPicker from "../components/ThemeColorPicker";
import CustomAlert from "./CustomAlert";
import DragNdropImage from "./DragNdropImage";
import CountryStateGenerator from "./CountryStateGenerator";
import useCreateOrg from "../api/CreateOrgAPI";
import { initialValues, validationSchema } from "./FormikValidation";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

const CreateOrganization = () => {
  const context = useOutletContext();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [selectedPrimaryColor, setPrimaryColor] = useState("");
  const [selectedSecondaryColor, setSecondaryColor] = useState("");
  const [selectedAccentColor, setAccentColor] = useState("");

  const handleAlertTimeout = () => {
    context.setAlert(null);
  };

  const handleAlert = (status, message) => {
    context.setAlert(
      <CustomAlert
        status={status}
        alerttitle={status === "success" ? "success" : "error"}
        alertmessage={message}
        onTimeout={handleAlertTimeout}
      />
    );
  };

  const CreateOrg = useCreateOrg(handleAlert);

  if (loading) {
    return (
      <Center w="full" h="full">
        <Spinner size="xl" />
      </Center>
    );
  }
  return (
    <Flex
      align="center"
      justifyContent="center"
      className="overscroll-y-contain"
      w="full"
    >
      <Box w="full">
        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={(values, { setSubmitting }) => {
            setLoading(true);
            CreateOrg(values)
              .then(() => {
                setLoading(false);
                setSubmitting(false);
                navigate("/Organizations");
              })
              .catch((error) => {
                setLoading(false);
                handleAlert("error", error);
                setSubmitting(false);
                navigate("/Organizations");
              });
          }}
        >
          {(formik) => (
            <Box p={4}>
              <Center>
                <Text
                  textAlign="center"
                  justify="center"
                  fontSize="4xl"
                  as="b"
                  my={4}
                  color="blue.700"
                >
                  Add Customer
                </Text>
              </Center>

              <Center>
                <Box
                  p={4}
                  width="100%"
                  maxW="5xl"
                  borderWidth="1px"
                  overflow="hidden"
                  borderRadius="lg"
                  boxShadow="md"
                >
                  <form onSubmit={formik.handleSubmit}>
                    <Stack direction="row" spacing={4} mt={6}>
                      <FormControl
                        isInvalid={
                          formik.touched.orgName && formik.errors.orgName
                        }
                      >
                        <FormLabel htmlFor="orgName">Business Name</FormLabel>
                        <Input
                          id="orgName"
                          type="text"
                          placeholder="Bussiness Name"
                          {...formik.getFieldProps("orgName")}
                        />
                        {formik.touched.orgName && formik.errors.orgName ? (
                          <FormErrorMessage>
                            {formik.errors.orgName}
                          </FormErrorMessage>
                        ) : null}
                      </FormControl>

                      <FormControl
                        isInvalid={
                          formik.touched.orgMail && formik.errors.orgMail
                        }
                      >
                        <FormLabel htmlFor="orgMail">Email</FormLabel>
                        <Input
                          id="orgMail"
                          type="orgMail"
                          placeholder="abc@gmail.com"
                          {...formik.getFieldProps("orgMail")}
                        />
                        {formik.touched.orgMail && formik.errors.orgMail ? (
                          <FormErrorMessage>
                            {formik.errors.orgMail}
                          </FormErrorMessage>
                        ) : null}
                      </FormControl>

                      <FormControl
                        isInvalid={
                          formik.touched.contact?.contactPerson &&
                          formik.errors.contact?.contactPerson
                        }
                      >
                        <FormLabel htmlFor="contactPerson">
                          Contact Person
                        </FormLabel>
                        <Input
                          id="contactPerson"
                          type="text"
                          placeholder="Smith"
                          {...formik.getFieldProps("contact.contactPerson")}
                        />
                        {formik.touched.contact?.contactPerson &&
                        formik.errors.contact?.contactPerson ? (
                          <FormErrorMessage>
                            {formik.errors.contact?.contactPerson}
                          </FormErrorMessage>
                        ) : null}
                      </FormControl>
                    </Stack>

                    <Stack direction="row" spacing={4} mt={6}>
                      <Box flex="2">
                        <FormControl
                          isInvalid={
                            formik.touched.region && formik.errors.region
                          }
                        >
                          <CountryStateGenerator
                            onCityChange={(getCity) => {
                              formik.setFieldValue("region", getCity, false);
                              formik.setFieldTouched("region", true);
                            }}
                            {...formik.getFieldProps("region")}
                          />
                          {formik.touched.region && formik.errors.region ? (
                            <FormErrorMessage>
                              {formik.errors.region}
                            </FormErrorMessage>
                          ) : null}
                        </FormControl>
                      </Box>

                      <Box flex="1">
                        <FormControl
                          isInvalid={
                            formik.touched.contact?.phone &&
                            formik.errors.contact?.phone
                          }
                        >
                          <FormLabel htmlFor="phone">Contact Number</FormLabel>
                          <PhoneInput
                            id="phone"
                            name="phone"
                            className="number oneTwo"
                            country={"us"}
                            placeholder="+91xxxxxx4232"
                            value={formik.values.contact.phone}
                            onChange={(phone) =>
                              formik.setFieldValue("contact.phone", phone)
                            }
                            onBlur={formik.handleBlur("contact.phone")}
                            containerClass="numberContainerClass"
                            inputClass="numberInputClass"
                            inputStyle={{
                              width: "100%",
                              borderColor:
                                formik.touched.contact?.phone &&
                                formik.errors.contact?.phone &&
                                "red",
                            }}
                          />
                          {formik.touched.contact?.phone &&
                          formik.errors.contact?.phone ? (
                            <FormErrorMessage>
                              {formik.errors.contact?.phone}
                            </FormErrorMessage>
                          ) : null}
                        </FormControl>
                      </Box>
                    </Stack>

                    <Stack direction="row" spacing={4} mt={6}>
                      <FormControl
                        isInvalid={
                          formik.touched.preferredLanguage &&
                          formik.errors.preferredLanguage
                        }
                      >
                        <FormLabel htmlFor="preferredLanguage">
                          Prefered Language
                        </FormLabel>
                        <Select
                          placeholder="Select Language"
                          id="preferredLanguage"
                          name="preferredLanguage"
                          {...formik.getFieldProps("preferredLanguage")}
                        >
                          <option value="English">English</option>
                          <option value="French">French</option>
                          <option value="Spanish">Spanish</option>
                          <option value="German">German</option>
                          <option value="Chinese">Chinese</option>
                          <option value="Japanese">Japanese</option>
                          <option value="Italian">Italian</option>
                          <option value="Dutch">Dutch</option>
                          <option value="Russian">Russian</option>
                          <option value="Arabic">Arabic</option>
                          <option value="Portuguese">Portuguese</option>
                          <option value="Hindi">Hindi</option>
                        </Select>
                        {formik.touched.preferredLanguage &&
                        formik.errors.preferredLanguage ? (
                          <FormErrorMessage>
                            {formik.errors.preferredLanguage}
                          </FormErrorMessage>
                        ) : null}
                      </FormControl>
                      <FormControl
                        isInvalid={
                          formik.touched.businessType &&
                          formik.errors.businessType
                        }
                      >
                        <FormLabel htmlFor="businessType">
                          Type of Business
                        </FormLabel>
                        <Select
                          placeholder="Select option"
                          id="businessType"
                          name="businessType"
                          {...formik.getFieldProps("businessType")}
                        >
                          <option value="Associate">Associate</option>
                          <option value="Corporate">Corporate</option>
                          <option value="Money Service">Money Service</option>
                          <option value="Partnership">Partnership</option>
                        </Select>
                        {formik.touched.businessType &&
                        formik.errors.businessType ? (
                          <FormErrorMessage>
                            {formik.errors.businessType}
                          </FormErrorMessage>
                        ) : null}
                      </FormControl>

                      <FormControl
                        isInvalid={
                          formik.touched.orgRegistrationDetails?.legalName &&
                          formik.errors.orgRegistrationDetails?.legalName
                        }
                      >
                        <FormLabel htmlFor="legalName">
                          Leagal Org Name
                        </FormLabel>
                        <Input
                          id="legalName"
                          type="text"
                          placeholder="Leagal Name"
                          {...formik.getFieldProps(
                            "orgRegistrationDetails.legalName"
                          )}
                        />
                        {formik.touched.orgRegistrationDetails?.legalName &&
                        formik.errors.orgRegistrationDetails?.legalName ? (
                          <FormErrorMessage>
                            {formik.errors.orgRegistrationDetails?.legalName}
                          </FormErrorMessage>
                        ) : null}
                      </FormControl>

                      <FormControl
                        isInvalid={
                          formik.touched.orgRegistrationDetails
                            ?.registrationNumber &&
                          formik.errors.orgRegistrationDetails
                            ?.registrationNumber
                        }
                      >
                        <FormLabel htmlFor="registrationNumber">
                          Reg Number
                        </FormLabel>
                        <Input
                          id="registrationNumber"
                          size="md"
                          placeholder="Valid Registation Number"
                          {...formik.getFieldProps(
                            "orgRegistrationDetails.registrationNumber"
                          )}
                        />

                        {formik.touched.orgRegistrationDetails
                          ?.registrationNumber &&
                        formik.errors.orgRegistrationDetails
                          ?.registrationNumber ? (
                          <FormErrorMessage>
                            {
                              formik.errors.orgRegistrationDetails
                                ?.registrationNumber
                            }
                          </FormErrorMessage>
                        ) : null}
                      </FormControl>
                      <FormControl
                        isInvalid={
                          formik.touched.orgRegistrationDetails
                            ?.incorporationDate &&
                          formik.errors.orgRegistrationDetails
                            ?.incorporationDate
                        }
                      >
                        <FormLabel htmlFor="incorporationDate">
                          Registration Date
                        </FormLabel>
                        <Input
                          id="incorporationDate"
                          type="datetime-local"
                          placeholder="Incorporation Date"
                          {...formik.getFieldProps(
                            "orgRegistrationDetails.incorporationDate"
                          )}
                        />
                        {formik.touched.orgRegistrationDetails
                          ?.incorporationDate &&
                        formik.errors.orgRegistrationDetails
                          ?.incorporationDate ? (
                          <FormErrorMessage>
                            {formik.errors.incorporationDate}
                          </FormErrorMessage>
                        ) : null}
                      </FormControl>
                    </Stack>

                    <Stack direction="row" spacing={4} mt={6}>
                      <Stack direction="column" flex="2">
                        <Stack direction="row">
                          <FormControl
                            isInvalid={
                              formik.touched.theme?.primary &&
                              formik.errors.theme?.primary
                            }
                          >
                            <Stack direction="row" gap={2} mb={1}>
                              <FormLabel htmlFor="primaryTheme">
                                Primary Color
                              </FormLabel>
                              {selectedPrimaryColor ? (
                                <Box
                                  width="15%"
                                  borderWidth={4}
                                  borderRadius={8}
                                  bg={selectedPrimaryColor.hex}
                                />
                              ) : (
                                ""
                              )}
                            </Stack>

                            <ThemeColorPicker
                              name="primaryTheme"
                              setColorChange={(setSelectedColor) => {
                                setPrimaryColor(setSelectedColor);
                                formik.setFieldValue(
                                  "theme.primary",
                                  setSelectedColor.hex,
                                  false
                                );
                                formik.setFieldTouched("theme.primary", true);
                              }}
                              {...formik.getFieldProps("theme.primary")}
                            />
                            {selectedPrimaryColor ? (
                              <Text
                                fontSize="xs"
                                m={2}
                                color={selectedPrimaryColor.hex}
                              >
                                {selectedPrimaryColor.hex}
                              </Text>
                            ) : (
                              <Text fontSize="xs" m={2} color="blue.500">
                                Select color
                              </Text>
                            )}

                            {formik.touched.theme?.primary &&
                            formik.errors.theme?.primary ? (
                              <FormErrorMessage>
                                {formik.errors.theme?.primary}
                              </FormErrorMessage>
                            ) : null}
                          </FormControl>
                          <FormControl
                            isInvalid={
                              formik.touched.theme?.secondary &&
                              formik.errors.theme?.secondary
                            }
                          >
                            <Stack direction="row" gap={2} mb={1}>
                              <FormLabel htmlFor="secondaryTheme">
                                Secondary color
                              </FormLabel>
                              {selectedSecondaryColor ? (
                                <Box
                                  width="15%"
                                  borderWidth={4}
                                  borderRadius={8}
                                  bg={selectedSecondaryColor.hex}
                                />
                              ) : (
                                ""
                              )}
                            </Stack>
                            <ThemeColorPicker
                              name="secondaryTheme"
                              setColorChange={(setSelectedColor) => {
                                setSecondaryColor(setSelectedColor);
                                formik.setFieldValue(
                                  "theme.secondary",
                                  setSelectedColor.hex,
                                  false
                                );
                                formik.setFieldTouched("theme.secondary", true);
                              }}
                              {...formik.getFieldProps("theme.secondary")}
                            />
                            {selectedSecondaryColor ? (
                              <Text
                                fontSize="xs"
                                m={2}
                                color={selectedSecondaryColor.hex}
                              >
                                {selectedSecondaryColor.hex}
                              </Text>
                            ) : (
                              <Text fontSize="xs" m={2} color="blue.500">
                                Select color
                              </Text>
                            )}
                            {formik.touched.theme?.secondary &&
                            formik.errors.theme?.secondary ? (
                              <FormErrorMessage>
                                {formik.errors.theme?.secondary}
                              </FormErrorMessage>
                            ) : null}
                          </FormControl>
                          <FormControl
                            isInvalid={
                              formik.touched.theme?.accent &&
                              formik.errors.theme?.accent
                            }
                          >
                            <Stack direction="row" gap={2} mb={1}>
                              <FormLabel htmlFor="accentTheme">
                                Accent color
                              </FormLabel>
                              {selectedAccentColor ? (
                                <Box
                                  width="15%"
                                  borderWidth={4}
                                  borderRadius={8}
                                  bg={selectedAccentColor.hex}
                                />
                              ) : (
                                ""
                              )}
                            </Stack>

                            <ThemeColorPicker
                              name="accentTheme"
                              setColorChange={(setSelectedColor) => {
                                setAccentColor(setSelectedColor);
                                formik.setFieldValue(
                                  "theme.accent",
                                  setSelectedColor.hex,
                                  false
                                );
                              }}
                            />
                            {selectedAccentColor ? (
                              <Text
                                fontSize="xs"
                                m={2}
                                color={selectedAccentColor.hex}
                              >
                                {selectedAccentColor.hex}
                              </Text>
                            ) : (
                              <Text fontSize="xs" m={2} color="blue.500">
                                Select color
                              </Text>
                            )}

                            {formik.touched.theme?.accent &&
                            formik.errors.theme?.accent ? (
                              <FormErrorMessage>
                                {formik.errors.theme?.accent}
                              </FormErrorMessage>
                            ) : null}
                          </FormControl>
                        </Stack>
                      </Stack>
                      <Stack direction="column" flex="1">
                        <Box flex="1">
                          <FormControl
                            isInvalid={
                              formik.touched.orgLogo && formik.errors.orgLogo
                            }
                          >
                            <FormLabel htmlFor="orgLogo">Logo</FormLabel>
                            <DragNdropImage
                              onFilesSelected={(selectedFiles) => {
                                formik.setFieldValue(
                                  "orgLogo",
                                  selectedFiles,
                                  false
                                );
                                formik.setFieldTouched("orgLogo", true);
                              }}
                              {...formik.getFieldProps("orgLogo")}
                            />
                            {formik.touched.orgLogo && formik.errors.orgLogo ? (
                              <FormErrorMessage>
                                {formik.errors.orgLogo}
                              </FormErrorMessage>
                            ) : null}
                          </FormControl>
                        </Box>
                      </Stack>
                    </Stack>

                    <Stack direction="row" spacing={8} mt={6}>
                      <Button
                        colorScheme="teal"
                        type="submit"
                        isLoading={false}
                        size="md"
                        width="200px"
                      >
                        Save
                      </Button>
                      <Button
                        colorScheme="red"
                        type="button"
                        onClick={() => {
                          navigate(-1);
                        }}
                        isLoading={false}
                        width="100px"
                      >
                        Cancel
                      </Button>
                    </Stack>
                  </form>
                </Box>
              </Center>
            </Box>
          )}
        </Formik>
      </Box>
    </Flex>
  );
};

export default CreateOrganization;
