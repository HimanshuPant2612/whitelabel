import React from "react";
import {
  Button,
  Box,
  Spacer,
  Flex,
  Input,
} from "@chakra-ui/react";
import { AddIcon } from "@chakra-ui/icons";
import { Form } from "react-router-dom";
import { SearchIcon } from "@chakra-ui/icons";
import Avatar from "../assests/Avatar.svg"

const OrgToolbar = ({
  searchQuery,
  setSearchQuery,
  addOrgButtonMarginTop,
}) => {
  const handleSearch = (event) => {
    setSearchQuery(event.target.value);
  };
  return (
    <Box w="100%" maxW="" h="100%" overflowY="auto" borderRadius="" boxShadow="" p={{ base: 2, md: 6 }} mx="auto" mt={{ base: '60px', md: 0 }}>
    <Flex
    mb={{ base: 4, md: 4 }}
    align={{ base: "stretch", md: "center" }}
    direction={{ base: "column-reverse", md: "row" }}
    gap={{ base: 2, md: 4 }}
  >
    <Form action={`/Organizations/createOrg`} style={{ width: '100%' }}>
      <Button
        leftIcon={<AddIcon />}
        type="submit"
        colorScheme="blue"
        bg="#0595D4"
        color="white"
        borderRadius="full"
        px={10}
        py={6}
        fontWeight="bold"
        fontSize="md"
        _hover={{ bg: "skyblue.500" }}
        boxShadow="sm"
        w={{ base: '100%', md: 'auto' }}
        mt={{ base: 2, md: 0 }}
      >
        Add Organization
      </Button>
    </Form>
    <Spacer />
<Box
w={{ base: "100%", md: "384px" }}
h="54px"
bg="white"
borderRadius="30px"
boxShadow="14px 17px 40px 4px rgba(112,144,176,0.08)"
display="flex"
alignItems="center"
px={4}
>
{/* Inner Violet Rounded Box */}
<Box
w="320px"
h="36px"
bg="#ede9ff"
borderRadius="49px"
display="flex"
alignItems="center"
px={4}
flexGrow={1}
gap={2}
>
<SearchIcon color="gray.500" boxSize={4} />
<Input
  variant="unstyled"
  placeholder="Search"
  value={searchQuery}
  onChange={handleSearch}
  size="md"
  _placeholder={{ color: "gray.500" }}
  border="none"
  outline="none"
  boxShadow="none"
  bg="transparent"
  _focus={{
    border: "none",
    outline: "none",
    boxShadow: "none",
    background: "transparent",
  }}
  _hover={{
    border: "none",
    outline: "none",
    boxShadow: "none",
    background: "transparent",
  }}
  autoComplete="off"
  width="100%"
/>
</Box>

{/* Image on right side */}
<Box
ml={6}
w="44px"
h="44px"
borderRadius="full"
overflow="hidden"
flexShrink={0}
>
<img
  src={Avatar}
  alt="Search Icon"
  style={{ width: "100%", height: "100%", objectFit: "cover" }}
/>
</Box>
</Box>

  </Flex>
  </Box>
  );
};

export default OrgToolbar;
