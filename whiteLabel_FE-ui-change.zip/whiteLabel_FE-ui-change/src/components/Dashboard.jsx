// import React, { useState } from "react";
// import { useBreakpointValue } from "@chakra-ui/react";
// import OrgToolbar from "./OrgToolbar";
// import ProfileTick from "../assests/profile-tick.png";
// import Organization from "../assests/organization.svg";
// import Profile from "../assests/profile.svg";

// export default function Dashboard() {
//   const [searchQuery, setSearchQuery] = useState("");
//   const addOrgButtonMarginTop = useBreakpointValue({ base: 16, md: 0 });
//   const stats = [
//     {
//       title: "Total Organizations",
//       value: "10",
//       iconSrc: Organization,
//       bgColor: "bg-cyan-100"
//     },
//     {
//       title: "Active Admins",
//       value: "25",
//       iconSrc: ProfileTick,
//       bgColor: "bg-cyan-100"
//     },
//     {
//       title: "Total Users",
//       value: "190",
//       iconSrc: Profile,
//       bgColor: "bg-cyan-100"
//     }
//   ];
//   return (
//     <>
//       <OrgToolbar
//         searchQuery={searchQuery}
//         setSearchQuery={setSearchQuery}
//         addOrgButtonMarginTop={addOrgButtonMarginTop}
//       />
//       <div className="w-full bg-white rounded-3xl shadow-lg p-4 md:p-8">
//         <div className="flex flex-col md:flex-row items-center md:items-stretch justify-between gap-6 md:gap-0">
//           {stats.map((stat, index) => (
//             <div key={index} className="flex flex-col md:flex-row items-center w-full md:w-auto">
//               <div className="flex items-center space-x-4 md:space-x-6 w-full md:w-auto">
//                 <div className={`w-16 h-16 md:w-20 md:h-20 ${stat.bgColor} rounded-full flex items-center justify-center`}>
//                   <img
//                     src={stat.iconSrc}
//                     alt={`${stat.title} icon`}
//                     className="w-8 h-8 md:w-10 md:h-10"
//                   />
//                 </div>
//                 <div className="flex flex-col items-center md:items-start">
//                   <span className="text-neutral-400 text-sm md:text-base font-normal font-inter">
//                     {stat.title}
//                   </span>
//                   <span className="text-sky-500 text-3xl md:text-5xl font-bold font-inter leading-tight">
//                     {stat.value}
//                   </span>
//                 </div>
//               </div>
//               {index < stats.length - 1 && (
//                 <div className="hidden md:block w-px h-20 bg-zinc-100 mx-12"></div>
//               )}
//             </div>
//           ))}
//         </div>
//       </div>
//     </>
//   );
// }

import React, { useState } from "react";
import { useBreakpointValue } from "@chakra-ui/react";
import OrgToolbar from "./OrgToolbar";
import ProfileTick from "../assests/profile-tick.png";
import Organization from "../assests/organization.svg";
import Profile from "../assests/profile.svg";

export default function Dashboard() {
  const [searchQuery, setSearchQuery] = useState("");
  const addOrgButtonMarginTop = useBreakpointValue({ base: 16, md: 0 });

  const stats = [
    {
      title: "Total Org.",
      value: "10",
      iconSrc: Organization
    },
    {
      title: "Active Admins",
      value: "25",
      iconSrc: ProfileTick
    },
    {
      title: "Total Users",
      value: "190",
      iconSrc: Profile
    }
  ];
  return (
    <div className="px-4 md:px-6">
        <OrgToolbar
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          addOrgButtonMarginTop={addOrgButtonMarginTop}
        />
        <div className="w-full bg-white rounded-2xl shadow-lg p-6 md:p-8">
        <div className="flex flex-row items-center justify-between gap-4 w-full mt-6">
  {stats.map((stat, index) => (
    <React.Fragment key={index}>
      <div className="flex flex-col items-center space-y-2 w-full">
        <div className="bg-cyan-100 rounded-full w-14 h-14 md:w-16 md:h-16 flex items-center justify-center">
          <img src={stat.iconSrc} alt="icon" className="w-6 h-6 md:w-8 md:h-8" />
        </div>
        <div className="text-center">
          <p className="text-neutral-400 text-xs md:text-sm">{stat.title}</p>
          <p className="text-sky-500 text-lg md:text-xl font-bold">{stat.value}</p>
        </div>
      </div>
      {/* Divider except after last item */}
      {index < stats.length - 1 && (
        <div className="hidden md:block h-16 border-r border-gray-300 mx-6" />
      )}
    </React.Fragment>
  ))}
</div>
      </div>
     </div>
  );
}