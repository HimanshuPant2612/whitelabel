import React, { useState, useEffect } from "react";
import { Country, State, City } from "country-state-city";
import { Select, Stack, Box, FormControl, FormLabel } from "@chakra-ui/react";

const CountryStateGenerator = ({ defaultCity, onCityChange }) => {
  const [selectedLocation, setSelectedLocation] = useState({
    country: defaultCity?.countryCode || "",
    state: defaultCity?.stateCode || "",
    city: defaultCity?.name || "",
    latitude: defaultCity?.lat || defaultCity?.latitude || "",
    longitude: defaultCity?.long || defaultCity?.longitude || "",
  });
  const [stateData, setStateData] = useState([]);
  const [cityData, setCityData] = useState([]);
  useEffect(() => {
    setStateData(State.getStatesOfCountry(selectedLocation.country));
  }, [selectedLocation.country]);

  useEffect(() => {
    setCityData(
      City.getCitiesOfState(selectedLocation.country, selectedLocation.state)
    );
  }, [selectedLocation.country, selectedLocation.state]);
  useEffect(() => {
    if (defaultCity) {
      setSelectedLocation({
        country: defaultCity.countryCode,
        state: defaultCity.stateCode,
        city: defaultCity.name,
        latitude: defaultCity?.lat || defaultCity?.latitude,
        longitude: defaultCity?.long || defaultCity?.longitude,
      });
    }
  }, [defaultCity]);

  const handleCountryChange = (event) => {
    const country = event.target.value;
    setSelectedLocation((prevLocation) => ({
      ...prevLocation,
      country,
      state: "",
      city: "",
      latitude: "",
      longitude: "",
    }));
  };

  const handleStateChange = (event) => {
    const state = event.target.value;
    setSelectedLocation((prevLocation) => ({
      ...prevLocation,
      state,
      city: "",
    }));
  };

  const handleCityChange = (event) => {
    const city = event.target.value;
    setSelectedLocation((prevLocation) => ({
      ...prevLocation,
      city,
    }));
    const selectedCity = cityData.find((cityItem) => cityItem.name === city);

    onCityChange(selectedCity);
  };

  useEffect(() => {
    if (defaultCity && cityData.length === 0) {
      onCityChange(defaultCity);
    }
  }, [defaultCity, cityData]);

  return (
    <Stack direction="row">
      <Box flex="1">
        <FormControl>
          <FormLabel htmlFor="country">Country</FormLabel>
          <Select
            id="country"
            placeholder="Select One"
            value={selectedLocation.country}
            onChange={handleCountryChange}
          >
            {Country.getAllCountries().map((country) => (
              <option key={country.isoCode} value={country.isoCode}>
                {country.name}
              </option>
            ))}
          </Select>
        </FormControl>
      </Box>

      <Box flex="1">
        <FormControl>
          <FormLabel htmlFor="state">State</FormLabel>
          <Select
            id="state"
            placeholder="Select option"
            value={selectedLocation.state}
            onChange={handleStateChange}
          >
            {stateData.map((singleState) => (
              <option key={singleState.isoCode} value={singleState.isoCode}>
                {singleState.name}
              </option>
            ))}
          </Select>
        </FormControl>
      </Box>

      <Box flex="1">
        <FormControl>
          <FormLabel htmlFor="city">City</FormLabel>
          <Select
            id="city"
            placeholder="Select option"
            value={selectedLocation.city}
            onChange={handleCityChange}
          >
            {cityData.map((singleCity) => (
              <option key={singleCity.name} value={singleCity.name}>
                {singleCity.name}
              </option>
            ))}
          </Select>
        </FormControl>
      </Box>
    </Stack>
  );
};

export default CountryStateGenerator;
