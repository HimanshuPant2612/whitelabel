import React, { useEffect } from "react";
import { useRouteError, useOutletContext } from "react-router-dom";
import CustomAlert from "../components/CustomAlert";

const ErrorPage = () => {
  const context = useOutletContext();
  const error = useRouteError();

  const handleAlertTimeout = () => {
    context.setAlert(null);
  };

  const handleAlert = (status, message) => {
    context.setAlert(
      <CustomAlert
        status={status}
        alerttitle={status === "success" ? "success" : "error"}
        alertmessage={message}
        onTimeout={handleAlertTimeout}
      />
    );
  };

  useEffect(() => {
    handleAlert("error", error.message);
    return () => {
      context.setAlert(null);
    };
  }, [error.message, context, handleAlert]);

  return (
    <div id="error-page">
      <h1>Oops!</h1>
      <p>Sorry, an Unexpected Error has Occured.</p>
      <p>
        <i>{error.statusText || error.message}</i>
      </p>
    </div>
  );
};

export default ErrorPage;
