import React, { useState, useContext } from "react";
import {
  Box,
  Spinner,
  Stack,
  Input,
  Button,
  Text,
  FormLabel,
  Center,
  FormControl,
  FormErrorMessage,
  useColorModeValue,
  Flex,
  Image,
  VStack,
} from "@chakra-ui/react";
import { Formik } from "formik";
import * as Yup from "yup";
import { useNavigate, useOutletContext } from "react-router-dom";
import CustomAlert from "../components/CustomAlert";
import { CreateContext } from "../context/ContextProvider";
import LoginAPI from "../api/LoginAPI";
import TGLogo from "../assests/TGLogo.png";

import Desktop from "../assests/Desktop.png";

const Login = () => {
  const navigate = useNavigate();
  const context = useOutletContext();
  const [loading, setLoading] = useState(false);
  const { setSuperToken } = useContext(CreateContext);
  
  // Move all useColorModeValue hooks to the top
  const bgColor = useColorModeValue("white", "gray.800");
  const leftBgColor = useColorModeValue("blue.50", "blue.900");
  const borderColor = useColorModeValue("black", "black");
  const pageBgColor = useColorModeValue("gray.100", "");

  const handleAlertTimeout = () => {
    context.setAlert(null);
  };
  const handleAlert = (status, message) => {
    context.setAlert(
      <CustomAlert
        status={status}
        alerttitle={status === "success" ? "success" : "error"}
        alertmessage={message}
        onTimeout={handleAlertTimeout}
      />
    );
  };
  const loginUser = LoginAPI(handleAlert);
  if (loading) {
    return (
      <Center w="full" h="full">
        <Spinner size="xl" color="blue.500" thickness="4px" />
      </Center>
    );
  }
  return (
    <Flex
      minH="100vh"
      w="full"
      bg={pageBgColor}
     // align="center"
      align={{ base: "flex-start", md: "center" }}
      justify="center"
    >
      <Flex
        w="full"
        maxW="1024px"
        bg={bgColor}
       // rounded="lg"
       rounded={{ base: "none", md: "lg" }}
        boxShadow={{ base: "none", md: "2xl" }}
        overflow="hidden"
        minH={{ base: "100vh", md: "auto" }}
      >
        {/* Left Side - Branding */}
        <Flex
          w="50%"
          bg={leftBgColor}
          p={8}
          direction="column"
          justify="center"
          align="center"
          display={{ base: "none", md: "flex" }}
          position="relative"
        >
          {/* <VStack spacing={8} align="center" position="relative" zIndex={2}>
            <Image src={TGLogo} h="50px" objectFit="contain" />
            <VStack spacing={4} align="center">
              <Text
                fontSize="lg"
                fontWeight="bold"
                color="blue.900"
                textAlign="center"
                letterSpacing="tight"
              >
                Welcome to Technogetic
              </Text>
              <Text
                fontSize="md"
                color="blue.900"
                textAlign="center"
                maxW="300px"
              >
                Where Innovation Meets Technology
              </Text>
            </VStack>
          </VStack> */}
          
          {/* Vector Image */}
          <Box
            position="absolute"
            bottom="0"
            left="0"
            right="0"
            height="100%"
            opacity="1"
           // backgroundImage="url('https://cdni.iconscout.com/illustration/premium/thumb/online-registration-4489364-3723270.png')"
             backgroundImage={Desktop}
            backgroundSize="cover"
            backgroundPosition="bottom"
            backgroundRepeat="no-repeat"
          />
        </Flex>
        {/* Right Side - Login Form */}
        <Flex w={{ base: "100%", md: "50%" }} p={8} direction="column" justify="center">
          <VStack spacing={2} align="center" mb={{ base: 16, md: 16 }} mt={{ base: -10, md: 2 }}>
            <Image src={TGLogo} h="50px"  objectFit="contain" />
            <Text
              fontSize="xl"
              fontWeight="bold"
              color="blue.700"
              letterSpacing="tight"
            >
              Welcome Back
            </Text>
            <Text color="gray.500" fontSize="sm" fontWeight="medium">
              Please sign in to continue
            </Text>
          </VStack>
          <Formik
            initialValues={{
              username: "",
              key: "",
            }}
            validationSchema={Yup.object({
              username: Yup.string().required("Enter User Name"),
              key: Yup.string().required("Enter Password"),
            })}
            onSubmit={(values, { setSubmitting }) => {
              setLoading(true);
              loginUser({ values, setLoading, setSuperToken })
                .then(() => {
                  setLoading(false);
                  setSubmitting(false);
                  navigate("/Organizations");
                })
                .catch((error) => {
                  setLoading(false);
                  handleAlert("error", error);
                  setSubmitting(false);
                  navigate("/");
                });
            }}
          >
            {(formik) => (
              <Box>
                <VStack spacing={6} align="stretch">
                  <form onSubmit={formik.handleSubmit}>
                    <Stack spacing={4} maxW="400px" mx="auto">
                      <FormControl
                        isInvalid={formik.touched.username && formik.errors.username}
                      >
                        <FormLabel htmlFor="username" fontWeight="bold" fontFamily={"sans-serif"} color={"blue.700"}>
                          Username
                        </FormLabel>
                        <Input
                          id="username"
                          type="text"
                          placeholder="Enter your username"
                          size="md"
                          {...formik.getFieldProps("username")}
                          border="none"
                          bg="gray.50"
                          boxShadow="sm"
                          _hover={{
                            boxShadow: "md",
                          }}
                          _focus={{
                            boxShadow: "md",
                            bg: "white",
                          }}
                        />
                        <Box className="error-container">
                          {formik.touched.username && formik.errors.username ? (
                            <FormErrorMessage>
                              {formik.errors.username}
                            </FormErrorMessage>
                          ) : null}
                        </Box>
                      </FormControl>

                      <FormControl
                        isInvalid={formik.touched.key && formik.errors.key}
                      >
                        <FormLabel htmlFor="key" fontWeight="bold" fontFamily={"sans-serif"}  color={"blue.700"}>
                          Password
                        </FormLabel>
                        <Input
                          id="key"
                          type="password"
                          placeholder="Enter your password"
                          size="md"
                          {...formik.getFieldProps("key")}
                          border="none"
                          bg="gray.50"
                          boxShadow="sm"
                          _hover={{
                            boxShadow: "md",
                          }}
                          _focus={{
                            boxShadow: "md",
                            bg: "white",
                          }}
                        />
                        <Box className="error-container">
                          {formik.touched.key && formik.errors.key ? (
                            <FormErrorMessage>
                              {formik.errors.key}
                            </FormErrorMessage>
                          ) : null}
                        </Box>
                      </FormControl>

                      <Button
                        type="submit"
                        colorScheme="blue"
                        size="md"
                        fontSize="md"
                        fontWeight="semibold"
                        isLoading={formik.isSubmitting}
                        loadingText="Signing in..."
                        width="100%"
                        _hover={{
                          transform: "translateY(-1px)",
                          boxShadow: "lg",
                        }}
                        _active={{
                          transform: "translateY(0)",
                        }}
                      >
                        Sign In
                      </Button>
                    </Stack>
                  </form>
                </VStack>
              </Box>
            )}
          </Formik>
        </Flex>
      </Flex>
    </Flex>
  );
};
export default Login;