import {
  Button,
  useDisclosure,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  ModalFooter,
} from "@chakra-ui/react";

import { ColorPicker, useColor } from "react-color-palette";
import "react-color-palette/css";

const ThemeColorPicker = (props) => {
  const { setColorChange } = props;
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [color, setColor] = useColor("#123123");

  const handleOnChange = (newColor) => {
    setColor(newColor);
    setColorChange(newColor);
  };
  return (
    <>
      <Button onClick={onOpen}>Open Color palette </Button>
      <Modal isOpen={isOpen} onClose={onClose}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Choose Color Scheme</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <ColorPicker
              hideInput={["rgb", "hsv"]}
              color={color}
              onChange={handleOnChange}
            />
          </ModalBody>
          <ModalFooter>
            <Button colorScheme="blue" onClick={onClose}>
              Save
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </>
  );
};

export default ThemeColorPicker;
