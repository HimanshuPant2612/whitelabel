import { useState, useEffect } from "react";
import { Box, Alert, AlertIcon, AlertDescription } from "@chakra-ui/react";

const CustomAlert = ({
  status = "success",
  alertmessage,
  top = "10px",
  right = "10px",
  minWidth = "150px",
  timeout = 4000,
  onTimeout,
}) => {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      if (onTimeout) {
        onTimeout();
      }
    }, timeout);

    return () => clearTimeout(timer);
  }, [timeout, onTimeout]);

  if (!isVisible) {
    return null;
  }
  return (
    <Alert
      status={status}
      position="absolute"
      top={top}
      right={right}
      width="auto"
      minWidth={minWidth}
      animation="fadeIn 0.5s ease-out"
      borderRadius="xl"
    >
      <AlertIcon />
      <Box flex="1" mr={4}>
        {alertmessage ? (
          <AlertDescription whiteSpace="nowrap">
            {alertmessage}
          </AlertDescription>
        ) : (
          "Success"
        )}
      </Box>
      {/* <CloseButton
        alignSelf="flex-start"
        position="relative"
        right={0}
        top={0}
        onClick={() => setIsVisible(false)}
      /> */}
    </Alert>
  );
};

export default CustomAlert;
