import React from "react";
import {
  Button,
  Modal,
  useDisclosure,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  IconButton,
  Box,
} from "@chakra-ui/react";
import { MdDelete } from "react-icons/md";
import { useNavigate } from "react-router-dom";
import useDeleteOrgAPI from "../api/DeleteOrgAPI";

const AlertModal = ({
  orgId,
  handleAlert,
  setLoading,
  setContacts,
  setCurrentPage,
}) => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const navigate = useNavigate();
  const deleteOrg = useDeleteOrgAPI(handleAlert);
  const handleDeleteOrg = async () => {
    try {
      setLoading(true);
      await deleteOrg(orgId);
      setLoading(false);
      onClose();
      handleAlert("success", "Deleted Successfully");
      navigate("/Organizations");
      setContacts((prevContacts) =>
        prevContacts.filter((contact) => contact._id !== orgId)
      );
      setCurrentPage(1);
    } catch (error) {
      setLoading(false);
      onClose();
      handleAlert("error", error.response.data.message);
      navigate("/Organizations");
    }
  };
  return (
    <>
      <IconButton
        size="sm"
        icon={<MdDelete />}
        type="submit"
        isLoading={false}
        variant="ghost"
        colorScheme="red"
          border="none"
      rounded="none"
      bg="white"
      color="red.500"
      _hover={{
        bg: "white",
        color: "red.500",
        boxShadow: "3px 0px 10px 4px rgba(13, 13, 13, 0.05)",
      }}
       boxShadow="3px 0px 10px 4px rgba(13, 13, 13, 0.05)"
        onClick={onOpen}
      />
      <Modal isOpen={isOpen} onClose={onClose}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Confirm Delete Organization Details</ModalHeader>
          <ModalCloseButton />
          <ModalBody>You really want do that</ModalBody>
          <ModalFooter>
            <Box mx={2}>
              <Button onClick={handleDeleteOrg}>Confirm</Button>
            </Box>
            <Box mx={2}>
              <Button colorScheme="green" mr={3} onClick={onClose}>
                Close
              </Button>
            </Box>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </>
  );
};
export default AlertModal;
