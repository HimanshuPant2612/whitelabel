// ValidationComponent.js
import * as Yup from "yup";

// InitialValuesComponent.js
export const initialValues = {
  orgName: "",
  orgMail: "",
  contact: {
    phone: "",
    contactPerson: "",
  },
  orgLogo: null,
  region: "",
  theme: {
    primary: "",
    secondary: "",
    accent: "",
  },
  orgRegistrationDetails: {
    legalName: "",
    registrationNumber: "",
    incorporationDate: "",
  },
  preferredLanguage: "",
  businessType: "",
};
export const validationSchema = Yup.object({
  orgName: Yup.string()
    .max(40, "Must be 40 characters or less")
    .required("Enter Business Name"),
  orgMail: Yup.string()
    .matches(
      /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
      "Invalid Email address"
    )
    .required("Required"),

  contact: Yup.object().shape({
    phone: Yup.string()
      .matches(/^\+?\d+$/, "Invalid phone number")
      .required("Required"),
    contactPerson: Yup.string().required("Required"),
  }),
  orgLogo: Yup.mixed().required("Enter The Logo"),
  region: Yup.object().required("Location is Required"),
  theme: Yup.object().shape({
    primary: Yup.string().required("Primary Color Required"),
    secondary: Yup.string().required("Secondary Color Required"),
    accent: Yup.string(),
  }),
  orgRegistrationDetails: Yup.object().shape({
    legalName: Yup.string().required("Enter Leagal Name"),
    registrationNumber: Yup.string().required("Enter Registration Number"),
    incorporationDate: Yup.string().required("Date of Incorporation"),
  }),
  preferredLanguage: Yup.string().required("Select Language"),
  businessType: Yup.string().required("Type of Bussiness"),
});

// const orgLogoValidation = (value) => {
//   if (!value) {
//     return Yup.string().required("Enter The Logo").validate(value);
//   } else if (typeof value === "string") {
//     return Yup.string()
//       .required("Enter The Logo")
//       .url("Invalid URL format")
//       .validate(value);
//   } else {
//     return Yup.mixed().required("Enter The Logo").validate(value);
//   }
// };
export const EditvalidationSchema = Yup.object({
  orgName: Yup.string()
    .max(40, "Must be 40 characters or less")
    .required("Enter Business Name"),
  orgMail: Yup.string()
    .matches(
      /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
      "Invalid Email address"
    )
    .required("Required"),
  contact: Yup.object().shape({
    phone: Yup.string()
      .matches(/^\+?\d+$/, "Invalid phone number")
      .required("Required"),
    contactPerson: Yup.string().required("Required"),
  }),
  // orgLogo: Yup.mixed().test("orgLogo", "Invalid Logo", orgLogoValidation),
  region: Yup.object().required("Location is Required"), // Adjusted to string validation
  theme: Yup.object().shape({
    primary: Yup.string().required("Primary Color Required"),
    secondary: Yup.string().required("Secondary Color Required"),
    accent: Yup.string(),
  }),
  orgRegistrationDetails: Yup.string().required("Enter Registration Details"),
});
