import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import reportWebVitals from "./reportWebVitals";
import "./index.css";
import Index from "./routes/index";
import ProtectedRoute from "./routes/ProtectedRoute";
import ErrorPage from "./components/Error_Page";
import Organizations from "./routes/Organizations";
import SingleOrg from "./routes/SingleOrg";
import EditOrg from "./routes/EditOrg";
import CreateOrganization from "../src/components/CreateOrganization";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { ChakraProvider } from "@chakra-ui/react";
import { ContextProvider } from "./context/ContextProvider";

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    errorElement: <ErrorPage />,
    children: [
      { index: true, element: <Index /> },

      {
        element: <ProtectedRoute />,
        children: [
          {
            // For Tabular View
            path: "Organizations",
            element: <Organizations />,
          },

          {
            // For single User Detail.
            path: "Organizations/:orgId",
            element: <SingleOrg />,
          },
          {
            // For Create new User.
            path: "Organizations/createOrg",
            element: <CreateOrganization />,
          },
          {
            // For Edit User Detail
            path: "Organizations/:contactId/editOrg",
            element: <EditOrg />,
          },
        ],
      },
    ],
    //   },
    // ],
  },
]);
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <ContextProvider>
      <ChakraProvider>
        <RouterProvider router={router} />
      </ChakraProvider>
    </ContextProvider>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
// reportWebVitals(console.log);
reportWebVitals();
