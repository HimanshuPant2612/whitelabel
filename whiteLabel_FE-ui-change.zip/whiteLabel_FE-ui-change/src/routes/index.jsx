// import React, { useContext } from "react";
// import { Link } from "react-router-dom";
// import { Flex, Box, Image, Text } from "@chakra-ui/react";
// import TGLogo from "../assests/TGLogo.png";
// import Login from "../components/Login";
// import { CreateContext } from "../context/ContextProvider";
// import Dashboard from "../components/Dashboard";

// export default function Index() {
//   const { superToken } = useContext(CreateContext);
//   return (
//     <Box width="100%">
//       {superToken && (
//         <Box
//           mt={8}
//           justifyContent="center"
//           alignItems="center"
//           textAlign="center"
//         >
//           <Flex justifyContent="center" alignItems="center">
//             <Image src={TGLogo} height="50px" />
//           </Flex>
//           <Text mt={4} fontSize="1lg">
//             Welcome to the <Link to="https://technogetic.com/">Technogetic</Link>.
//           </Text>
//           <Text fontSize="1lg">Where Inovation Meet's with Technology.</Text>
//         </Box>
//       )}
//       <Box width="100%">
//         {superToken ? (
//           <Box
//             mt={8}
//             justifyContent="center"
//             alignItems="center"
//             textAlign="center"
//           >
//             <Text fontSize="3xl" color="cyan.900">
//               Welcome Admin
//             </Text>
//           </Box>
//         ) : (
//           <Login />
//         )}
//       </Box>
//     </Box>
//   );
// }


import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { Flex, Box, Image, Text } from "@chakra-ui/react";
import TGLogo from "../assests/TGLogo.png";
import Login from "../components/Login";
import { CreateContext } from "../context/ContextProvider";
import Dashboard from "../components/Dashboard";

export default function Index() {
  const { superToken } = useContext(CreateContext);

  if (!superToken) {
    return <Login />;
  }

  return (
    <Box width="100%">
      {/* Optional: Welcome Section */}
      {/* <Box mt={8} justifyContent="center" alignItems="center" textAlign="center">
        <Flex justifyContent="center" alignItems="center">
          <Image src={TGLogo} height="50px" />
        </Flex>
        <Text mt={4} fontSize="lg">
          Welcome to the{" "}
          <Link to="https://technogetic.com/" style={{ color: "blue" }}>
            Technogetic
          </Link>
          .
        </Text>
        <Text fontSize="lg">Where Innovation Meets Technology.</Text>
        <Text fontSize="3xl" color="cyan.900" mt={4}>
          Welcome Admin
        </Text>
      </Box> */}

      {/* Render the Dashboard */}
      <Box mt={0}>
        <Dashboard />
      </Box>
    </Box>
  );
}
