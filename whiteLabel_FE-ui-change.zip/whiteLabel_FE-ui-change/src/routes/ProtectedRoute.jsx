import React, { useEffect } from "react";
import {
  useNavigate,
  useOutletContext,
  Outlet,
  Navigate,
} from "react-router-dom";

const ProtectedRoute = () => {
  const context = useOutletContext();
  const navigate = useNavigate();
  const sessionAuthToken = localStorage.getItem("AuthToken");

  useEffect(() => {
    // If the user is not authenticated, redirect to "/"
    if (!context.authToken && !sessionAuthToken) {
      navigate("/", { replace: true });
    }
  }, [context.authToken, sessionAuthToken, navigate]);

  useEffect(() => {
    // Check if AuthToken is present and redirect to last visited URL upon refresh
    if (
      (context.authToken || sessionAuthToken) &&
      window.location.pathname === "/"
    ) {
      const lastVisitedUrl = localStorage.getItem("lastVisitedUrl");
      if (lastVisitedUrl) {
        navigate(lastVisitedUrl, { replace: true });
      }
    }
  }, [context.authToken, sessionAuthToken, navigate]);

  // Render the protected route or redirect to "/"
  return context.authToken || sessionAuthToken ? (
    <Outlet context={context} />
  ) : (
    <Navigate to="/" replace />
  );
};

export default ProtectedRoute;
