import { useState, useEffect } from "react";
import { useNavigate, useParams, useOutletContext } from "react-router-dom";
import {
  Text,
  Center,
  Spinner,
  Stack,
  Box,
  Flex,
  FormLabel,
  FormControl,
  Button,
  Image,
  Spacer,
} from "@chakra-ui/react";
import { ArrowBackIcon } from "@chakra-ui/icons";
import CustomAlert from "../components/CustomAlert";
import SingleOrgAPI from "../api/SingleOrgAPI";

const SingleOrg = () => {
  const context = useOutletContext();
  const { orgId } = useParams();
  const [singlecontact, setContact] = useState();
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleAlertTimeout = () => {
    context.setAlert(null);
  };

  const handleAlert = (status, message) => {
    context.setAlert(
      <CustomAlert
        status={status}
        alerttitle={status === "success" ? "success" : "error"}
        alertmessage={message}
        onTimeout={handleAlertTimeout}
      />
    );
  };

  const SingleOrg = SingleOrgAPI(handleAlert);

  useEffect(() => {
    const fetchContact = async () => {
      setLoading(true);
      SingleOrg({
        orgId,
        setContact,
        setLoading,
      }).finally(() => {
        setLoading(false);
      });
    };
    localStorage.setItem("lastVisitedUrl", window.location.pathname);
    fetchContact();
  }, [orgId]);

  if (loading) {
    return (
      <Center w="full" h="full">
        <Spinner size="xl" />
      </Center>
    );
  }

  // Helper function to safely display object values
  const displayValue = (value) => {
    if (value === null || value === undefined) return "NILL";
    if (typeof value === "object") {
      return JSON.stringify(value);
    }
    return value;
  };

  return (
    <>
      <Box p={10} width="100%">
        <Flex>
          <Button
            leftIcon={<ArrowBackIcon />}
            colorScheme="teal"
            variant="ghost"
            onClick={() => {
              navigate("/Organizations");
            }}
            isLoading={false}
          >
            Back
          </Button>
          <Spacer />
        </Flex>

        <Stack direction="row" spacing={4} mt={6}>
          <Box flex="1">
            <Stack direction="column" spacing={6}>
              <FormControl>
                <FormLabel htmlFor="orgName">Organization Name</FormLabel>
                <Box p={2} width="100%" borderWidth={1} borderRadius={8}>
                  {displayValue(singlecontact?.orgName)}
                </Box>
              </FormControl>
              <FormControl>
                <FormLabel htmlFor="email">Email</FormLabel>
                <Box p={2} width="100%" borderWidth={1} borderRadius={8}>
                  {displayValue(singlecontact?.orgMail)}
                </Box>
              </FormControl>
            </Stack>
          </Box>

          <Box flex="1">
            <Stack direction="column" spacing={6}>
              <FormControl>
                <FormLabel htmlFor="contactPerson">Contact Person</FormLabel>
                <Box p={2} width="100%" borderWidth={1} borderRadius={8}>
                  {displayValue(singlecontact?.contact?.contactPerson)}
                </Box>
              </FormControl>

              <FormControl>
                <FormLabel htmlFor="phoneNumber">Contact Number</FormLabel>
                <Box p={2} width="100%" borderWidth={1} borderRadius={8}>
                  {displayValue(singlecontact?.contact?.phone)}
                </Box>
              </FormControl>
            </Stack>
          </Box>
          <Box flex="1">
            <FormControl>
              <FormLabel>Organization Logo</FormLabel>
              <Box
                p={2}
                width="100%"
                borderWidth={1}
                borderRadius={8}
                className="text-center"
              >
                <Image
                  src={singlecontact?.orgLogo?.orgLogoUrl}
                  alt="Company Logo"
                  fallbackSrc="https://via.placeholder.com/150"
                />
              </Box>
            </FormControl>
          </Box>
        </Stack>
        <Stack direction="row" spacing={4} mt={6}>
          <Box flex="2">
            <Stack direction="row" spacing={4}>
              <Box flex="1">
                <FormControl>
                  <Stack direction="row">
                    <Stack direction="column">
                      <FormLabel htmlFor="primary">Primary Color</FormLabel>
                    </Stack>
                    <Box
                      width="15%"
                      borderWidth={1}
                      borderRadius={8}
                      bg={singlecontact?.theme?.primary}
                    />
                  </Stack>
                  <Stack direction="row">
                    <Text as="b">
                      {displayValue(singlecontact?.theme?.primary)}
                    </Text>
                  </Stack>
                </FormControl>
              </Box>
              <Box flex="1">
                <FormControl>
                  <Stack direction="row">
                    <Stack direction="column">
                      <FormLabel htmlFor="secondary">Secondary Color</FormLabel>
                    </Stack>
                    <Box
                      width="15%"
                      borderWidth={1}
                      borderRadius={8}
                      bg={singlecontact?.theme?.secondary}
                    />
                  </Stack>
                  <Stack direction="row">
                    <Text as="b">
                      {displayValue(singlecontact?.theme?.secondary)}
                    </Text>
                  </Stack>
                </FormControl>
              </Box>

              <Box flex="1">
                <FormControl>
                  <Stack direction="row">
                    <Stack direction="column">
                      <FormLabel htmlFor="accent">Accent Color</FormLabel>
                    </Stack>
                    <Box
                      width="15%"
                      borderWidth={1}
                      borderRadius={8}
                      bg={singlecontact?.theme?.accent}
                    />
                  </Stack>
                  <Stack direction="row">
                    <Text as="b">{displayValue(singlecontact?.theme?.accent)}</Text>
                  </Stack>
                </FormControl>
              </Box>
            </Stack>

            <Stack direction="row" spacing={4}>
              <FormControl mt={6}>
                <FormLabel htmlFor="RegistrationDetails">Details</FormLabel>
                <Box p={2} width="100%" borderWidth={1} borderRadius={8}>
                  {displayValue(singlecontact?.orgRegistrationDetails)}
                </Box>
              </FormControl>
            </Stack>
          </Box>
          <Box flex="1">
            <FormControl>
              <FormLabel htmlFor="Locations">Location Details</FormLabel>
              <Box p={2} width="100%" borderWidth={1} borderRadius={8}>
                {singlecontact?.region?.name && singlecontact?.region?.stateCode && singlecontact?.region?.countryCode
                  ? `${singlecontact.region.name}, ${singlecontact.region.stateCode}, ${singlecontact.region.countryCode}`
                  : "NILL"}
              </Box>
            </FormControl>
            <Stack direction="row" mt={4}>
              <FormControl>
                <FormLabel htmlFor="ThemeColors">Longitude</FormLabel>
                <Box p={2} width="100%" borderWidth={1} borderRadius={8}>
                  {displayValue(singlecontact?.region?.long || singlecontact?.region?.longitude)}
                </Box>
              </FormControl>

              <FormControl>
                <FormLabel htmlFor="ThemeColors">Latitude</FormLabel>
                <Box p={2} width="100%" borderWidth={1} borderRadius={8}>
                  {displayValue(singlecontact?.region?.lat || singlecontact?.region?.latitude)}
                </Box>
              </FormControl>
            </Stack>
          </Box>
        </Stack>
      </Box>
    </>
  );
};
export default SingleOrg;
