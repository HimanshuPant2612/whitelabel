// import React, { useState, useEffect } from "react";
// import { Form, useOutletContext } from "react-router-dom";
// import { ChevronLeftIcon, ChevronRightIcon } from "@chakra-ui/icons";
// import {
//   Spinner,
//   Center,
//   Image,
//   Button,
//   Box,
//   Table,
//   Thead,
//   Tbody,
//   Tr,
//   Th,
//   Td,
//   TableContainer,
//   Icon,
//   Flex,
//   Spacer,
//   Input,
//   IconButton,
//   useBreakpointValue,
//   HStack,
//   InputGroup,
//   InputLeftElement,
//   Text,
// } from "@chakra-ui/react";
// import { ViewIcon, AddIcon, SearchIcon } from "@chakra-ui/icons";
// import { MdEdit } from "react-icons/md";
// import { FaHospitalUser } from "react-icons/fa";
// import CustomAlert from "../components/CustomAlert";
// import AlertModal from "../components/AlertModal";
// import RetreveOrgAPI from "../api/RetreveOrgAPI";

// const formatDate = (dateString) => {
//   if (!dateString) return "NIL";
//   const date = new Date(dateString);
//   return `${String(date.getDate()).padStart(2, "0")}/${String(date.getMonth() + 1).padStart(2, "0")}/${date.getFullYear()}`;
// };
// const Organizations = () => {
//   const [contacts, setContacts] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [searchQuery, setSearchQuery] = useState("");
//   const isMobile = useBreakpointValue({ base: true, md: false });

//   const [currentPage, setCurrentPage] = useState(1);
//   const contactsPerPage = 8;
//   const indexOfLastContact = currentPage * contactsPerPage;
//   const indexOfFirstContact = indexOfLastContact - contactsPerPage;

//   const context = useOutletContext();

//   const handleAlertTimeout = () => {
//     context.setAlert(null);
//   };
//   const handleAlert = (status, message) => {
//     context.setAlert(
//       <CustomAlert
//         status={status}
//         alerttitle={status === "success" ? "success" : "error"}
//         alertmessage={message}
//         onTimeout={handleAlertTimeout}
//       />
//     );
//   };
//   const allOrg = RetreveOrgAPI(handleAlert);

//   useEffect(() => {
//     const fetchContacts = async () => {
//       setLoading(true);
//       try {
//         const data = await allOrg({
//           currentPage,
//           contactsPerPage,
//         });
//         setContacts(data?.organizations || []);
//       } catch (error) {
//         handleAlert("error", "Failed to load contacts");
//       } finally {
//         setLoading(false);
//       }
//     };
//     localStorage.setItem("lastVisitedUrl", window.location.pathname);
//     fetchContacts();
//   }, [currentPage, searchQuery]);

//   const paginate = (pageNumber) => setCurrentPage(pageNumber);

//   const filteredContacts = contacts?.filter((contact) =>
//     contact?.orgName?.toLowerCase()?.includes(searchQuery.toLowerCase())
//   );

//   const handleSearch = (event) => {
//     event.preventDefault();
//     setSearchQuery(event.target.value);
//     setCurrentPage(1);
//   };

//   if (loading) {
//     return (
//       <Center w="full" h="full">
//         <Spinner size="xl" />
//       </Center>
//     );
//   }
//   return (
//     <Box w="100%" maxW="100%" h="100%" overflowY="auto" borderRadius="px" boxShadow="md" p={{ base: 2, md: 6 }} mx="auto" mt={{ base: '60px', md: 0 }}>
//       <Flex
//         mb={{ base: 4, md: 4 }}
//         align={{ base: "stretch", md: "center" }}
//         direction={{ base: "column-reverse", md: "row" }}
//         gap={{ base: 2, md: 4 }}
//       >
//         <Form action={`createOrg`} style={{ width: '100%' }}>
//           <Button
//             leftIcon={<AddIcon />}
//             type="submit"
//             colorScheme="blue"
//             bg="#0595D4"
//             color="white"
//             borderRadius="full"
//             px={6}
//             py={2}
//             fontWeight="bold"
//             fontSize="md"
//             _hover={{ bg: "#1565c0" }}
//             boxShadow="sm"
//             w={{ base: '100%', md: 'auto' }}
//             mt={{ base: 2, md: 0 }}
//           >
//             Add Organization
//           </Button>
//         </Form>
//         <Spacer />
//         <Box w={{ base: "100%", md: "320px" }}>
//           <InputGroup>
//             <InputLeftElement pointerEvents="none">
//               <SearchIcon color="gray.400" />
//             </InputLeftElement>
//             <Input
//               size="md"
//               id="q"
//               aria-label="Search contacts"
//               placeholder="Search"
//               type="search"
//               name="q"
//               value={searchQuery}
//               onChange={handleSearch}
//               borderRadius="full"
//               bg="#f5f7fa"
//               border="none"
//               _focus={{ bg: "white", border: "1px solid #1976d2" }}
//               boxShadow="sm"
//             />
//           </InputGroup>
//         </Box>
//       </Flex>

//       <TableContainer
//         borderRadius="xl"
//         boxShadow="sm"
//         bg="white"
//         overflowX="auto"
//         minW="900px"
//         marginBottom={4}
//         border="none"
//       >
//         <Table size="sm" variant="simple" colorScheme="gray">
//           <Thead>
//             <Tr bg="#CBF3FF" borderTopRadius="l" h="48px">
//               <Th fontSize="sm" color="#0D1F36" fontWeight="medium">DATE</Th>
//               <Th fontSize="sm" color="#0D1F36" fontWeight="medium">CONTACT PERSON</Th>
//               <Th fontSize="sm" color="#0D1F36" fontWeight="medium">BUSINESS NAME</Th>
//               <Th fontSize="sm" color="#0D1F36" fontWeight="medium">EMAIL</Th>
//               <Th fontSize="sm" color="#0D1F36" fontWeight="medium">PHONE NUMBER</Th>
//               <Th fontSize="sm" color="#0D1F36" fontWeight="medium">LONGITUDE</Th>
//               <Th fontSize="sm" color="#0D1F36" fontWeight="medium">LATITUDE</Th>
//               <Th fontSize="sm" color="#0D1F36" fontWeight="medium">ACTION</Th>
//             </Tr>
//           </Thead>
//           <Tbody>
//             {filteredContacts
//               ?.slice(indexOfFirstContact, indexOfLastContact)
//               .map((contacts) => (
//                 <Tr key={contacts._id} _hover={{ bg: "gray.50" }}>
//                   <Td>{formatDate(contacts?.createdAt)}</Td>
//                   <Td>{contacts?.contact?.contactPerson || <i>NIL</i>}</Td>
//                   <Td>
//                     <Flex align="center">
//                       {contacts?.orgLogo?.orgLogoUrl ? (
//                         <Image
//                           borderRadius="full"
//                           boxSize="24px"
//                           src={contacts?.orgLogo?.orgLogoUrl}
//                           alt="Logo"
//                           mr={2}
//                         />
//                       ) : (
//                         <Icon as={FaHospitalUser} boxSize={4} mr={2} />
//                       )}
//                       <Text>{contacts?.orgName || <i>Empty Business Name</i>}</Text>
//                     </Flex>
//                   </Td>
//                   <Td>{contacts?.orgMail || <i>No Web Url</i>}</Td>
//                   <Td>{contacts?.contact?.phone || <i>NIL</i>}</Td>
//                   <Td>{contacts?.region?.long || contacts?.region?.longitude || <i>NIL</i>}</Td>
//                   <Td>{contacts?.region?.lat || contacts?.region?.latitude || <i>NIL</i>}</Td>
//                   <Td>
//                     <HStack spacing={1}>
//                       <Form action={contacts?._id}>
//                         <IconButton
//                           size="sm"
//                           icon={<ViewIcon />}
//                           type="submit"
//                           aria-label="View"
//                           colorScheme="blue"
//                           variant="ghost"
//                         />
//                       </Form>
//                       <Form action={`${contacts?._id}/editOrg`}>
//                         <IconButton
//                           size="sm"
//                           icon={<MdEdit />}
//                           type="submit"
//                           aria-label="Edit"
//                           colorScheme="blue"
//                           variant="ghost"
//                         />
//                       </Form>
//                       <AlertModal
//                         orgId={contacts?._id}
//                         handleAlert={handleAlert}
//                         setLoading={setLoading}
//                         setContacts={setContacts}
//                         setCurrentPage={setCurrentPage}
//                       />
//                     </HStack>
//                   </Td>
//                 </Tr>
//               ))}
//           </Tbody>
//         </Table>

//         <Flex justify="flex-end" align="center" mt={4} w="full">
//           <Text fontSize="sm" color="gray.500" mr={4}>
//             {filteredContacts.length > 0
//               ? `${currentPage} of ${Math.ceil(filteredContacts.length / contactsPerPage)}`
//               : "0 of 0"}
//           </Text>
//           <HStack spacing={1}>
//             <IconButton
//               icon={<ChevronLeftIcon boxSize={5} />}
//               onClick={() => paginate(currentPage - 1)}
//               isDisabled={currentPage === 1}
//               aria-label="Previous page"
//               variant="ghost"
//               size="sm"
//               bg="transparent"
//               border="none"
//               boxShadow="none"
//               _hover={{ bg: "transparent", color: "#3182CE" }}
//               _active={{ bg: "transparent" }}
//               _focus={{ boxShadow: "none" }}
//               _disabled={{ opacity: 0.3, cursor: "not-allowed" }}
//             />
//             <IconButton
//               icon={<ChevronRightIcon boxSize={5} />}
//               onClick={() => paginate(currentPage + 1)}
//               isDisabled={currentPage >= Math.ceil(filteredContacts.length / contactsPerPage)}
//               aria-label="Next page"
//               variant="ghost"
//               size="sm"
//               bg="transparent"
//               border="none"
//               boxShadow="none"
//               _disabled={{ opacity: 0.3, cursor: "not-allowed" }}
//             />
//           </HStack>
//         </Flex>
//       </TableContainer>
//     </Box>
//   );
// };

// export default Organizations;
// import React, { useState, useEffect, useRef } from "react";
// import { Form, useOutletContext } from "react-router-dom";
// import { ChevronLeftIcon, ChevronRightIcon } from "@chakra-ui/icons";
// import {
//   Spinner,
//   Center,
//   Image,
//   Button,
//   Box,
//   Table,
//   Thead,
//   Tbody,
//   Tr,
//   Th,
//   Td,
//   TableContainer,
//   Icon,
//   Flex,
//   Spacer,
//   Input,
//   IconButton,
//   useBreakpointValue,
//   HStack,
//   Text,
// } from "@chakra-ui/react";
// import { ViewIcon, AddIcon, SearchIcon } from "@chakra-ui/icons";
// import { MdEdit } from "react-icons/md";
// import { FaHospitalUser } from "react-icons/fa";
// import CustomAlert from "../components/CustomAlert";
// import AlertModal from "../components/AlertModal";
// import RetreveOrgAPI from "../api/RetreveOrgAPI";
// import SearchPopup from "../components/SearchPopup";
// import ArrowIcon from '../assests/Arrow.svg';
// import Avatar from "../assests/Avatar.svg";

// const formatDate = (dateString) => {
//   if (!dateString) return "NIL";
//   const date = new Date(dateString);
//   return `${String(date.getDate()).padStart(2, "0")}/${String(
//     date.getMonth() + 1
//   ).padStart(2, "0")}/${date.getFullYear()}`;
// };
// const Organizations = () => {
//   const [contacts, setContacts] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [searchQuery, setSearchQuery] = useState("");
//   const isMobile = useBreakpointValue({ base: true, md: false });
//   const [currentPage, setCurrentPage] = useState(1);
//   const contactsPerPage = 8;
//   const indexOfLastContact = currentPage * contactsPerPage;
//   const indexOfFirstContact = indexOfLastContact - contactsPerPage;
//   //const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
//   const context = useOutletContext();
//   const inputRef = useRef(null);

//   const handleAlertTimeout = () => {
//     context.setAlert(null);
//   };
//   const handleAlert = (status, message) => {
//     context.setAlert(
//       <CustomAlert
//         status={status}
//         alerttitle={status === "success" ? "success" : "error"}
//         alertmessage={message}
//         onTimeout={handleAlertTimeout}
//       />
//     );
//   };
//   const allOrg = RetreveOrgAPI(handleAlert);
//   useEffect(() => {
//     const fetchContacts = async () => {
//       setLoading(true);
//       try {
//         const data = await allOrg({
//           currentPage,
//           contactsPerPage, searchQuery
//         });
//         setContacts(data?.organizations || []);
//       } catch (error) {
//         handleAlert("error", "Failed to load contacts");
//       } finally {
//         setLoading(false);
//       }
//     };
//     localStorage.setItem("lastVisitedUrl", window.location.pathname);
//     fetchContacts();
//   }, [currentPage]); // 🔥 FIXED: Removed `searchQuery`

//   useEffect(() => {
//     inputRef.current?.focus();
//   }, []);

//   const paginate = (pageNumber) => setCurrentPage(pageNumber);

//   const filteredContacts = contacts?.filter((contact) =>
//     contact?.orgName?.toLowerCase()?.includes(searchQuery.toLowerCase())
//   );
//   const handleSearch = (event) => {
//     setSearchQuery(event.target.value);
//     setCurrentPage(1);
//   };
//   // Sorting logic
//   // const handleSort = (key) => {
//   //   setSortConfig((prev) => {
//   //     if (prev.key === key) {
//   //       // Toggle direction
//   //       return { key, direction: prev.direction === 'asc' ? 'desc' : 'asc' };
//   //     }
//   //     return { key, direction: 'asc' };
//   //   });
//   // };
//   // const sortedContacts = [...filteredContacts].sort((a, b) => {
//   //   if (!sortConfig.key) return 0;
//   //   let aValue, bValue;
//   //   switch (sortConfig.key) {
//   //     case 'date':
//   //       aValue = a.createdAt;
//   //       bValue = b.createdAt;
//   //       break;
//   //     case 'contactPerson':
//   //       aValue = a.contact?.contactPerson || '';
//   //       bValue = b.contact?.contactPerson || '';
//   //       break;
//   //     case 'orgName':
//   //       aValue = a.orgName || '';
//   //       bValue = b.orgName || '';
//   //       break;
//   //     default:
//   //       return 0;
//   //   }
//   //   if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
//   //   if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
//   //   return 0;
//   // });
//   if (loading) {
//     return (
//       <Center w="full" h="full">
//         <Spinner size="xl" />
//       </Center>
//     );
//   }
//   return (
//     <Box
//       w="100%"
//       maxW="100%"
//       h="100%"
//       overflowY="auto"
//       borderRadius="px"
//       boxShadow="md"
//       p={{ base: 2, md: 6 }}
//       mx="auto"
//       mt={{ base: "60px", md: 0 }}
//     >
//       <Flex
//         mb={{ base: 4, md: 4 }}
//         align={{ base: "stretch", md: "center" }}
//         direction={{ base: "column-reverse", md: "row" }}
//         gap={{ base: 2, md: 4 }}
//       >
//         <Form action={`createOrg`} style={{ width: "100%" }}>
//           <Button
//             leftIcon={<AddIcon />}
//             type="submit"
//             colorScheme="blue"
//             bg="#0595D4"
//             color="white"
//             borderRadius="full"
//             px={8}
//             py={6}
//             fontWeight="bold"
//             fontSize="md"
//             _hover={{ bg: "none" }}
//             boxShadow="sm"
//             w={{ base: "100%", md: "auto" }}
//             mt={{ base: 2, md: 0 }}
//           >
//             Add Organization
//           </Button>
//         </Form>
//         <Spacer/>
//         <Box position="relative" w={{ base: "100%", md: "384px" }}>
//           <Box
//             h="54px"
//             bg="white"
//             borderRadius="30px"
//             boxShadow="14px 17px 40px 4px rgba(112,144,176,0.08)"
//             display="flex"
//             alignItems="center"
//             px={4}
//           >
//             <Box
//               w="320px"
//               h="36px"
//               bg="#ede9ff"
//               borderRadius="49px"
//               display="flex"
//               alignItems="center"
//               px={4}
//               flexGrow={1}
//               gap={2}
//             >
//               <SearchIcon color="gray.500" boxSize={4} />
//               <Input
//                 ref={inputRef}
//                 variant="unstyled"
//                 placeholder="Search"
//                 value={searchQuery}
//                 onChange={handleSearch}
//                 size="md"
//                 _placeholder={{ color: "gray.500" }}
//                 border="none"
//                 outline="none"
//                 boxShadow="none"
//                 bg="transparent"
//                 _focus={{
//                   border: "none",
//                   outline: "none",
//                   boxShadow: "none",
//                   background: "transparent",
//                 }}
//                 _hover={{
//                   border: "none",
//                   outline: "none",
//                   boxShadow: "none",
//                   background: "transparent",
//                 }}
//                 autoComplete="off"
//                 width="100%"
//               />
//             </Box>
//             <Box
//               ml={6}
//               w="44px"
//               h="44px"
//               borderRadius="full"
//               overflow="hidden"
//               flexShrink={0}
//             >
//               <img
//                 src="Avatar"
//                 alt="Search Icon"
//                 style={{ width: "100%", height: "100%", objectFit: "cover" }}
//               />
//             </Box>
//           </Box>

//           {searchQuery && (
//             <SearchPopup results={filteredContacts.slice(0, 5)} />
//           )}
//         </Box>
//       </Flex>

//       <TableContainer
//         borderRadius="xl"
//         boxShadow="sm"
//         bg="white"
//         overflowX="auto"
//         minW="900px"
//         marginBottom={4}
//         border="none"
//       >
//         <Table size="sm" variant="simple" colorScheme="gray">
//           <Thead>
//             <Tr bg="#CBF3FF" borderTopRadius="l" h="48px">
//               <Th fontSize="sm" color="#0D1F36" fontWeight="medium" className="cursor-pointer" >
//                 <span className="flex items-center gap-1">
//                   DATE
//                   <img src={ArrowIcon} alt="sort"
//                    //className={`transition-transform ${sortConfig.key === 'date' && sortConfig.direction === 'desc' ? 'rotate-180' : ''}`} 

//                    />
//                 </span>
//               </Th>
//               <Th fontSize="sm" color="#0D1F36" fontWeight="medium" className="cursor-pointer">
//                 <span className="flex items-center gap-1">
//                   CONTACT PERSON
//                   <img src={ArrowIcon} alt="sort" 
//                  // className={`transition-transform ${sortConfig.key === 'contactPerson' && sortConfig.direction === 'desc' ? 'rotate-180' : ''}`} 

//                   />
//                 </span>
//               </Th>
//               <Th fontSize="sm" color="#0D1F36" fontWeight="medium" className="cursor-pointer">
//                 <span className="flex items-center gap-1">
//                   BUSINESS NAME
//                   <img src={ArrowIcon} alt="sort" 
//                   //className={`transition-transform ${sortConfig.key === 'orgName' && sortConfig.direction === 'desc' ? 'rotate-180' : ''}`}
//                    />
//                 </span>
//               </Th>
//               <Th fontSize="sm" color="#0D1F36" fontWeight="medium">EMAIL</Th>
//               <Th fontSize="sm" color="#0D1F36" fontWeight="medium">PHONE NUMBER</Th>
//               <Th fontSize="sm" color="#0D1F36" fontWeight="medium">LONGITUDE</Th>
//               <Th fontSize="sm" color="#0D1F36" fontWeight="medium">LATITUDE</Th>
//               <Th fontSize="sm" color="#0D1F36" fontWeight="medium">ACTION</Th>
//             </Tr>
//           </Thead>
//           <Tbody>
//             {sortedContacts
//               ?.slice(indexOfFirstContact, indexOfLastContact)
//               .map((contacts) => (
//                 <Tr key={contacts._id} _hover={{ bg: "gray.50" }}>
//                   <Td>{formatDate(contacts?.createdAt)}</Td>
//                   <Td>{contacts?.contact?.contactPerson || <i>NIL</i>}</Td>
//                   <Td>
//                     <Flex align="center">
//                       {contacts?.orgLogo?.orgLogoUrl ? (
//                         <Image
//                           borderRadius="full"
//                           boxSize="24px"
//                           src={contacts?.orgLogo?.orgLogoUrl}
//                           alt="Logo"
//                           mr={2}
//                         />
//                       ) : (
//                         <Icon as={FaHospitalUser} boxSize={4} mr={2} />
//                       )}
//                       <Text>{contacts?.orgName || <i>Empty Business Name</i>}</Text>
//                     </Flex>
//                   </Td>
//                   <Td>{contacts?.orgMail || <i>No Web Url</i>}</Td>
//                   <Td>{contacts?.contact?.phone || <i>NIL</i>}</Td>
//                   <Td>{contacts?.region?.long || contacts?.region?.longitude || <i>NIL</i>}</Td>
//                   <Td>{contacts?.region?.lat || contacts?.region?.latitude || <i>NIL</i>}</Td>
//                   <Td>
//                     <HStack spacing={2}>
//                       <Form action={contacts?._id}>
//                         <IconButton
//                           size="sm"
//                           icon={<ViewIcon />}
//                           type="submit"
//                           aria-label="View"
//                           bg="white"
//                           border="none"
//                           rounded="none"
//                           colorScheme="blue"
//                           variant="ghost"
//                           color="blue.500"
//                           boxShadow="3px 0px 10px 4px rgba(13, 13, 13, 0.05)"
//                           _hover={{
//                             bg: "white",
//                             color: "blue.500",
//                             boxShadow: "3px 0px 10px 4px rgba(13, 13, 13, 0.05)",
//                           }}
//                         />
//                       </Form>
//                       <Form action={`${contacts?._id}/editOrg`}>
//                         <IconButton
//                           size="sm"
//                           icon={<MdEdit />}
//                           type="submit"
//                           aria-label="Edit"
//                           colorScheme="blue"
//                           variant="ghost"
//                           bg="white"
//                           border="none"
//                           rounded="none"
//                           color="blue.500"
//                           boxShadow="3px 0px 10px 4px rgba(13, 13, 13, 0.05)"
//                           _hover={{
//                             bg: "white",
//                             color: "blue.500",
//                             boxShadow: "3px 0px 10px 4px rgba(13, 13, 13, 0.05)",
//                           }}
//                         />
//                       </Form>
//                       <AlertModal
//                         orgId={contacts?._id}
//                         handleAlert={handleAlert}
//                         setLoading={setLoading}
//                         setContacts={setContacts}
//                         setCurrentPage={setCurrentPage}
//                       />
//                     </HStack>
//                   </Td>
//                 </Tr>
//               ))}
//           </Tbody>
//         </Table>
//         <Flex justify="flex-end" align="center" mt={4} w="full">
//           <Text fontSize="sm" color="gray.500" mr={4}>
//             {filteredContacts.length > 0
//               ? `${currentPage} of ${Math.ceil(filteredContacts.length / contactsPerPage)}`
//               : "0 of 0"}
//           </Text>
//           <HStack spacing={1}>
//             <IconButton
//               icon={<ChevronLeftIcon boxSize={5} />}
//               onClick={() => paginate(currentPage - 1)}
//               isDisabled={currentPage === 1}
//               aria-label="Previous page"
//               variant="ghost"
//               size="sm"
//               bg="transparent"
//               border="none"
//               boxShadow="none"
//               _hover={{ bg: "transparent", color: "#3182CE" }}
//               _active={{ bg: "transparent" }}
//               _focus={{ boxShadow: "none" }}
//               _disabled={{ opacity: 0.3, cursor: "not-allowed" }}
//             />
//             <IconButton
//               icon={<ChevronRightIcon boxSize={5} />}
//               onClick={() => paginate(currentPage + 1)}
//               isDisabled={
//                 currentPage >= Math.ceil(filteredContacts.length / contactsPerPage)
//               }
//               aria-label="Next page"
//               variant="ghost"
//               size="sm"
//               bg="transparent"
//               border="none"
//               boxShadow="none"
//               _disabled={{ opacity: 0.3, cursor: "not-allowed" }}
//             />
//           </HStack>
//         </Flex>
//       </TableContainer>
//     </Box>
//   );
// };
// export default Organizations;


import React, { useState, useEffect ,useRef } from "react";
import { Form, useOutletContext } from "react-router-dom";
import { ChevronLeftIcon, ChevronRightIcon } from "@chakra-ui/icons";
import {
  Spinner,
  Center,
  Image,
  Button,
  Box,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  TableContainer,
  Icon,
  Flex,
  Spacer,
  Input,
  IconButton,
  useBreakpointValue,
  HStack,
  InputGroup,
  InputLeftElement,
  Text,
} from "@chakra-ui/react";
import { ViewIcon, AddIcon, SearchIcon } from "@chakra-ui/icons";
import { MdEdit } from "react-icons/md";
import { FaHospitalUser } from "react-icons/fa";
import CustomAlert from "../components/CustomAlert";
import AlertModal from "../components/AlertModal";
import RetreveOrgAPI from "../api/RetreveOrgAPI";
import SearchPopup from "../components/SearchPopup";
import ArrowIcon from '../assests/Arrow.svg';
import Avatar from "../assests/Avatar.svg"

const formatDate = (dateString) => {
  if (!dateString) return "NIL";
  const date = new Date(dateString);
  return `${String(date.getDate()).padStart(2, "0")}/${String(date.getMonth() + 1).padStart(2, "0")}/${date.getFullYear()}`;
};

const Organizations = () => {
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const contactsPerPage = 8;

  const isMobile = useBreakpointValue({ base: true, md: false });
  const context = useOutletContext();
  const inputRef = useRef(null);

  const handleAlertTimeout = () => {
    context.setAlert(null);
  };

  const handleAlert = (status, message) => {
    context.setAlert(
      <CustomAlert
        status={status}
        alerttitle={status === "success" ? "success" : "error"}
        alertmessage={message}
        onTimeout={handleAlertTimeout}
      />
    );
  };

  const allOrg = RetreveOrgAPI(handleAlert);

  useEffect(() => {
    const fetchContacts = async () => {
      setLoading(true);
      try {
        const data = await allOrg({
          currentPage,
          contactsPerPage,
          searchQuery,
        });
        setContacts(data?.organizations || []);
        setTotalPages(data?.totalPages || 0);
      } catch (error) {
        handleAlert("error", "Failed to load contacts");
      } finally {
        setLoading(false);
      }
    };

    localStorage.setItem("lastVisitedUrl", window.location.pathname);
    fetchContacts();
  }, [currentPage]);
          useEffect(()=>
          {
            inputRef.current?.focus();
          },[]);

  const paginate = (pageNumber) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };
  const filteredContacts = contacts?.filter((contact) =>
   contact?.orgName?.toLowerCase()?.includes(searchQuery.toLowerCase()));

  const handleSearch = (event) => {
    setSearchQuery(event.target.value);
    //setCurrentPage(1);
  };

  if (loading) {
    return (
      <Center w="full" h="full">
        <Spinner size="xl" />
      </Center>
    );
  }
  return (
    <Box w="100%" maxW="100%" h="100%" overflowY="auto" borderRadius="px" boxShadow="md" p={{ base: 2, md: 6 }} mx="auto" mt={{ base: '60px', md: 0 }}>
      <Flex
        mb={{ base: 4, md: 4 }}
        align={{ base: "stretch", md: "center" }}
        direction={{ base: "column-reverse", md: "row" }}
        gap={{ base: 2, md: 4 }}
      >
        <Form action={`createOrg`} style={{ width: "100%" }}>
          <Button
            leftIcon={<AddIcon />}
            type="submit"
            colorScheme="blue"
            bg="#0595D4"
            color="white"
            borderRadius="full"
            px={8}
            py={6}
            fontWeight="bold"
            fontSize="md"
            _hover={{ bg: "none" }}
            boxShadow="sm"
            w={{ base: "100%", md: "auto" }}
            mt={{ base: 2, md: 0 }}
          >
            Add Organization
          </Button>
        </Form>
        <Spacer/>
        <Box position="relative" w={{ base: "100%", md: "384px" }}>
          <Box
            h="54px"
            bg="white"
            borderRadius="30px"
            boxShadow="14px 17px 40px 4px rgba(112,144,176,0.08)"
            display="flex"
            alignItems="center"
            px={4}
          >
            <Box
              w="320px"
              h="36px"
              bg="#ede9ff"
              borderRadius="49px"
              display="flex"
              alignItems="center"
              px={4}
              flexGrow={1}
              gap={2}
            >
              <SearchIcon color="gray.500" boxSize={4} />
              <Input
                ref={inputRef}
                variant="unstyled"
                placeholder="Search"
                value={searchQuery}
                onChange={handleSearch}
                size="md"
                _placeholder={{ color: "gray.500" }}
                border="none"
                outline="none"
                boxShadow="none"
                bg="transparent"
                _focus={{
                  border: "none",
                  outline: "none",
                  boxShadow: "none",
                  background: "transparent",
                }}
                _hover={{
                  border: "none",
                  outline: "none",
                  boxShadow: "none",
                  background: "transparent",
                }}
                autoComplete="off"
                width="100%"
              />
            </Box>
            <Box
              ml={6}
              w="44px"
              h="44px"
              borderRadius="full"
              overflow="hidden"
              flexShrink={0}
            >
              <img
                src={Avatar}
                alt="Search Icon"
                style={{ width: "100%", height: "100%", objectFit: "cover" }}
              />
            </Box>
          </Box>

          {searchQuery && (
            <SearchPopup results={filteredContacts.slice(0, 5)} />
          )}
        </Box>
      </Flex>
      <TableContainer borderRadius="xl" boxShadow="sm" bg="white" overflowX="auto" minW="900px" marginBottom={4} border="none">
        <Table size="sm" variant="simple" colorScheme="gray">
          <Thead>
            <Tr bg="#CBF3FF" h="48px">
              <Th><span className="flex items-center gap-1">DATE <img src={ArrowIcon} alt="sort"/></span></Th>
              <Th><span className="flex items-center gap-1">CONTACT PERSON <img src={ArrowIcon} alt="sort"/></span></Th>
              <Th><span className="flex items-center gap-1">BUSINESS NAME <img src={ArrowIcon} alt="sort"/></span></Th>
              <Th>EMAIL</Th>
              <Th>PHONE NUMBER</Th>
              <Th>LONGITUDE</Th>
              <Th>LATITUDE</Th>
              <Th>ACTION</Th>
            </Tr>
          </Thead>
          <Tbody>
            {contacts.map((org) => (
              <Tr key={org._id} _hover={{ bg: "gray.50" }}>
                <Td>{formatDate(org?.createdAt)}</Td>
                <Td>{org?.contact?.contactPerson || <i>NIL</i>}</Td>
                <Td>
                  <Flex align="center">
                    {org?.orgLogo?.orgLogoUrl ? (
                      <Image borderRadius="full" boxSize="24px" src={org?.orgLogo?.orgLogoUrl} alt="Logo" mr={2} />
                    ) : (
                      <Icon as={FaHospitalUser} boxSize={4} mr={2} />
                    )}
                    <Text>{org?.orgName || <i>Empty Business Name</i>}</Text>
                  </Flex>
                </Td>
                <Td>{org?.orgMail || <i>No Web Url</i>}</Td>
                <Td>{org?.contact?.phone || <i>NIL</i>}</Td>
                <Td>{org?.region?.long || org?.region?.longitude || <i>NIL</i>}</Td>
                <Td>{org?.region?.lat || org?.region?.latitude || <i>NIL</i>}</Td>
                <Td>
                  <HStack spacing={1}>
                    <Form action={org?._id}>
                      <IconButton size="sm" icon={<ViewIcon />} type="submit" aria-label="View" colorScheme="blue" variant="ghost"
                      bg="white" border="none" rounded="none" 
                      color="blue.500" boxShadow="3px 0px 10px 4px rgba(13, 13, 13, 0.05)"
                      _hover={{ bg: "white", color: "blue.500", boxShadow: "3px 0px 10px 4px rgba(13, 13, 13, 0.05)" }}
                       />
                    </Form>
                    <Form action={`${org?._id}/editOrg`}>
                      <IconButton size="sm" icon={<MdEdit />} type="submit" aria-label="Edit" colorScheme="blue" variant="ghost"
                      bg="white" border="none" rounded="none"
                      color="blue.500" boxShadow="3px 0px 10px 4px rgba(13, 13, 13, 0.05)"
                      _hover={{ bg: "white", color: "blue.500", boxShadow: "3px 0px 10px 4px rgba(13, 13, 13, 0.05)" }}
                       />
                    </Form>
                    <AlertModal
                      orgId={org?._id}
                      handleAlert={handleAlert}
                      setLoading={setLoading}
                      setContacts={setContacts}
                      setCurrentPage={setCurrentPage}
                    />
                  </HStack>
                </Td>
              </Tr>
            ))}
          </Tbody>
        </Table>
        <Flex justify="flex-end" align="center" mt={4} w="full">
          <Text fontSize="sm" color="gray.500" mr={4}>
            {totalPages > 0 ? `${currentPage} of ${totalPages}` : "0 of 0"}
          </Text>
          <HStack spacing={1}>
            <IconButton
              icon={<ChevronLeftIcon boxSize={5} />}
              onClick={() => paginate(currentPage - 1)}
              isDisabled={currentPage === 1}
              aria-label="Previous page"
              variant="ghost"
              size="sm"
              bg="transparent"
              border="none"
              boxShadow="none"
              _hover={{ bg: "transparent", color: "#3182CE" }}
              _active={{ bg: "transparent" }}
              _focus={{ boxShadow: "none" }}
              _disabled={{ opacity: 0.3, cursor: "not-allowed" }}
            />
            <IconButton
              icon={<ChevronRightIcon boxSize={5} />}
              onClick={() => paginate(currentPage + 1)}
              isDisabled={currentPage >= totalPages}
              aria-label="Next page"
              variant="ghost"
              size="sm"
              bg="transparent"
               border="none"
               _hover={{ bg: "white", color: "none" }}
              _disabled={{ opacity: 0.3, cursor: "not-allowed" }}
            />
          </HStack>
        </Flex>
      </TableContainer>
    </Box>
  );
};
export default Organizations;
