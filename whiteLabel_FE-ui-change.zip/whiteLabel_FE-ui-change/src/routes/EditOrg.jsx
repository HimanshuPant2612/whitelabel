import React, { useState, useEffect } from "react";
import { useNavigate, useParams, useOutletContext } from "react-router-dom";
import {
  FormErrorMessage,
  Image,
  Input,
  Textarea,
  Stack,
  Box,
  Flex,
  FormLabel,
  FormControl,
  Button,
  Spacer,
  Spinner,
  Center,
} from "@chakra-ui/react";
import { Formik } from "formik";
import { EditvalidationSchema } from "../components/FormikValidation";
import { ArrowBackIcon } from "@chakra-ui/icons";
// import { UpdateOrganization } from "../api/UpdateOrgAPI";
import CustomAlert from "../components/CustomAlert";
import CountryStateGenerator from "../components/CountryStateGenerator";
import DragNdropImage from "../components/DragNdropImage";
import useAxios from "../api/Axios";
import useUpdateDetails from "../api/UpdateOrgAPI";

const EditOrg = () => {
  const context = useOutletContext();
  const navigate = useNavigate();
  const { contactId } = useParams();
  const [singlecontact, setContact] = useState();
  const [loading, setLoading] = useState(false);
  const [localImg, setLocalImg] = useState();

  useEffect(() => {
    if (singlecontact && singlecontact.orgLogo) {
      setLocalImg(singlecontact?.orgLogo?.orgLogoUrl || "");
    }
  }, [singlecontact]);

  const handleAlertTimeout = () => {
    context.setAlert(null);
  };

  const handleAlert = (status, message) => {
    context.setAlert(
      <CustomAlert
        status={status}
        alerttitle={status === "success" ? "success" : "error"}
        alertmessage={message}
        onTimeout={handleAlertTimeout}
      />
    );
  };
  const axiosInstance = useAxios(handleAlert);
  const UpdateOrganization = useUpdateDetails(handleAlert);

  useEffect(() => {
    const fetchContact = async () => {
      setLoading(true);
      try {
        const response = await axiosInstance.get(`/organizations/${contactId}`);
        setContact(response.data);
      } catch (err) {
        handleAlert("error", err.message);
      } finally {
        setLoading(false);
      }
    };
    localStorage.setItem("lastVisitedUrl", window.location.pathname);
    fetchContact();
  }, [context?.authToken]);

  if (loading) {
    return (
      <Center w="full" h="full">
        <Spinner size="xl" />
      </Center>
    );
  }

  return (
    <Formik
      initialValues={{
        orgName: singlecontact?.orgName || "null",
        orgMail: singlecontact?.orgMail || "null",
        contact: {
          phone: singlecontact?.contact?.phone || "null",
          contactPerson: singlecontact?.contact?.contactPerson || "null",
        },
        orgLogo: null,
        region: "",
        theme: {
          primary: singlecontact?.theme?.primary || "null",
          secondary: singlecontact?.theme?.secondary || "null",
          accent: singlecontact?.theme?.accent || "null",
        },
        orgRegistrationDetails: singlecontact?.orgRegistrationDetails || "null",
      }}
      // validationSchema={{validationSchema}}
      validationSchema={EditvalidationSchema}
      onSubmit={(values, { setSubmitting }) => {
        setLoading(true);
        UpdateOrganization(values, singlecontact._id)
          .then(() => {
            setLoading(false);
            setSubmitting(false);
            navigate("/Organizations");
          })
          .catch((error) => {
            setLoading(false);
            handleAlert("error", error);
            setSubmitting(false);
            navigate("/Organizations");
          });
      }}
    >
      {(formik) => (
        <Box p={10} width="100%">
          <Flex>
            <Button
              leftIcon={<ArrowBackIcon />}
              colorScheme="teal"
              variant="ghost"
              onClick={() => {
                navigate("/Organizations");
              }}
              isLoading={false}
            >
              Back
            </Button>
            <Spacer />
          </Flex>
          <form onSubmit={formik.handleSubmit}>
            <Stack direction="row" spacing={4} mt={6}>
              <Box flex="2">
                <Stack direction="row" w="full">
                  <Stack direction="row" w="full">
                    <Box flex="1">
                      <Stack direction="column" spacing={6}>
                        <FormControl
                          isInvalid={
                            formik.touched.orgName && formik.errors.orgName
                          }
                        >
                          <FormLabel htmlFor="orgName">Business Name</FormLabel>
                          <Input
                            id="orgName"
                            name="orgName"
                            type="text"
                            {...formik.getFieldProps("orgName")}
                          />
                          <FormErrorMessage minHeight="20px">
                            {formik.touched.orgName && formik.errors.orgName ? (
                              <>{formik.errors.orgName}</>
                            ) : null}
                          </FormErrorMessage>
                        </FormControl>

                        <FormControl
                          isInvalid={
                            formik.touched.orgMail && formik.errors.orgMail
                          }
                        >
                          <FormLabel htmlFor="email">Email</FormLabel>
                          <Input
                            id="orgMail"
                            type="email"
                            {...formik.getFieldProps("orgMail")}
                          />
                          <FormErrorMessage minHeight="20px">
                            {formik.touched.orgMail && formik.errors.orgMail ? (
                              <>{formik.errors.orgMail}</>
                            ) : null}
                          </FormErrorMessage>
                        </FormControl>
                      </Stack>
                    </Box>

                    <Box flex="1">
                      <Stack direction="column" spacing={6}>
                        <FormControl
                          isInvalid={
                            formik.touched.contact?.contactPerson &&
                            formik.contact?.contactPerson
                          }
                        >
                          <FormLabel htmlFor="contactPerson">
                            Contact Person
                          </FormLabel>
                          <Input
                            id="contactPerson"
                            type="text"
                            {...formik.getFieldProps("contact.contactPerson")}
                          />
                          <FormErrorMessage minHeight="20px">
                            {formik.touched.contact?.contactPerson &&
                            formik.errors.contact?.contactPerson ? (
                              <>{formik.errors.contact?.contactPerson}</>
                            ) : null}
                          </FormErrorMessage>
                        </FormControl>

                        <FormControl
                          isInvalid={
                            formik.touched.contact?.phone &&
                            formik.errors.contact?.phone
                          }
                        >
                          <FormLabel htmlFor="phone">Contact Number</FormLabel>
                          <Input
                            id="phone"
                            type="text"
                            {...formik.getFieldProps("contact.phone")}
                          />
                          <FormErrorMessage minHeight="20px">
                            {formik.touched.contact?.phone &&
                            formik.errors.contact?.phone ? (
                              <>{formik.errors.contact?.phone}</>
                            ) : null}
                          </FormErrorMessage>
                        </FormControl>
                      </Stack>
                    </Box>
                  </Stack>
                </Stack>

                <Stack direction="row" spacing={4} mt={8}>
                  <Box flex="1" gap={0} m={0} p={0}>
                    <FormControl>
                      <Stack direction="row" gap={0} m={0} p={0}>
                        <Stack direction="column" gap={4}>
                          <FormControl
                            isInvalid={
                              formik.touched.theme?.primary &&
                              formik.errors.theme?.primary
                            }
                          >
                            <FormLabel htmlFor="primaryTheme">
                              Primary Color Code
                            </FormLabel>
                            <Input
                              id="primaryTheme"
                              name="primaryTheme"
                              type="text"
                              onChange={(event) => {
                                formik.setFieldValue(
                                  "theme.primary",
                                  event.target.value,
                                  false
                                );
                              }}
                              {...formik.getFieldProps("theme.primary")}
                            />
                            <FormErrorMessage minHeight="20px">
                              {formik.touched.theme?.primary &&
                              formik.errors.theme?.primary ? (
                                <>{formik.errors.primary?.accent}</>
                              ) : null}
                            </FormErrorMessage>
                          </FormControl>
                        </Stack>
                        <Box
                          width="20%"
                          height={8}
                          borderWidth={1}
                          borderRadius={8}
                          bg={singlecontact?.theme?.primary}
                        />
                      </Stack>
                    </FormControl>
                  </Box>

                  <Box flex="1" gap={0} m={0} p={0}>
                    <FormControl>
                      <Stack direction="row" gap={0} m={0} p={0}>
                        <Stack direction="column" gap={4}>
                          <FormControl
                            isInvalid={
                              formik.touched.theme?.secondary &&
                              formik.errors.theme?.secondary
                            }
                          >
                            <FormLabel htmlFor="secondaryTheme">
                              Second Color Code
                            </FormLabel>
                            <Input
                              id="secondaryTheme"
                              name="secondaryTheme"
                              type="text"
                              onChange={(event) => {
                                formik.setFieldValue(
                                  "theme.secondary",
                                  event.target.value,
                                  false
                                );
                              }}
                              {...formik.getFieldProps("theme.secondary")}
                            />
                            <FormErrorMessage minHeight="20px">
                              {formik.touched.theme?.secondary &&
                              formik.errors.theme?.secondary ? (
                                <>{formik.errors.theme?.secondary}</>
                              ) : null}
                            </FormErrorMessage>
                          </FormControl>
                        </Stack>
                        <Box
                          width="20%"
                          height={8}
                          borderWidth={1}
                          borderRadius={8}
                          bg={singlecontact?.theme?.secondary}
                        />
                      </Stack>
                    </FormControl>
                  </Box>

                  <Box flex="1" gap={0} m={0} p={0}>
                    <FormControl>
                      <Stack direction="row" gap={0} m={0} p={0}>
                        <Stack direction="column" gap={4}>
                          <FormControl
                            isInvalid={
                              formik.touched.theme?.accent &&
                              formik.errors.theme?.accent
                            }
                          >
                            <FormLabel htmlFor="accentTheme">
                              Accent Color Code
                            </FormLabel>
                            <Input
                              id="accentTheme"
                              name="accentTheme"
                              type="text"
                              onChange={(event) => {
                                formik.setFieldValue(
                                  "theme.accent",
                                  event.target.value,
                                  false
                                );
                              }}
                              {...formik.getFieldProps("theme.accent")}
                            />
                            <FormErrorMessage minHeight="20px">
                              {formik.touched.theme?.accent &&
                              formik.errors.theme?.accent ? (
                                <>{formik.errors.theme?.accent}</>
                              ) : null}
                            </FormErrorMessage>
                          </FormControl>
                        </Stack>
                        <Box
                          width="20%"
                          height={8}
                          borderWidth={1}
                          borderRadius={8}
                          bg={singlecontact?.theme?.accent}
                        />
                      </Stack>
                    </FormControl>
                  </Box>
                </Stack>
              </Box>

              <Box flex="1">
                <FormControl>
                  <Box
                    p={2}
                    width="100%"
                    borderWidth={1}
                    borderRadius={8}
                    className="text-center"
                  >
                    <Image
                      mb={4}
                      src={
                        localImg ? localImg : singlecontact?.orgLogo?.orgLogoUrl
                      }
                      alt="Company Logo"
                      // fallbackSrc="https://via.placeholder.com/150"
                    />
                    <DragNdropImage
                      onFilesSelected={(selectedFiles) => {
                        setLocalImg(selectedFiles);
                        formik.setFieldValue("orgLogo", selectedFiles, false);
                      }}
                    />
                  </Box>
                </FormControl>
              </Box>
            </Stack>

            {/* <Stack direction="row" spacing={4} mt={6}>
              <Box flex="1">
                <FormControl
                  isInvalid={
                    formik.touched.theme?.primary &&
                    formik.errors.theme?.primary
                  }
                >
                  <FormLabel htmlFor="primaryTheme">
                    Primary Color Code
                  </FormLabel>
                  <Input
                    id="primaryTheme"
                    name="primaryTheme"
                    type="text"
                    onChange={(event) => {
                      formik.setFieldValue(
                        "theme.primary",
                        event.target.value,
                        false
                      );
                    }}
                    {...formik.getFieldProps("theme.primary")}
                  />
                  <FormErrorMessage minHeight="20px">
                    {formik.touched.theme?.primary &&
                    formik.errors.theme?.primary ? (
                      <>{formik.errors.theme?.primary}</>
                    ) : null}
                  </FormErrorMessage>
                </FormControl>
              </Box>

              <Box flex="1">
                <FormControl>
                  <FormLabel htmlFor="secondaryTheme">
                    Secondary Color Code
                  </FormLabel>
                  <Input
                    id="secondaryTheme"
                    name="secondaryTheme"
                    type="text"
                    onChange={(event) => {
                      formik.setFieldValue(
                        "theme.secondary",
                        event.target.value,
                        false
                      );
                    }}
                    {...formik.getFieldProps("theme.secondary")}
                  />
                </FormControl>
              </Box>

              <Box flex="1">
                <FormControl
                  isInvalid={
                    formik.touched.theme?.accent && formik.errors.theme?.accent
                  }
                >
                  <FormLabel htmlFor="accentTheme">Accent Color Code</FormLabel>
                  <Input
                    id="accentTheme"
                    name="accentTheme"
                    type="text"
                    onChange={(event) => {
                      formik.setFieldValue(
                        "theme.accent",
                        event.target.value,
                        false
                      );
                    }}
                    {...formik.getFieldProps("theme.accent")}
                  />
                  <FormErrorMessage minHeight="20px">
                    {formik.touched.theme?.accent &&
                    formik.errors.theme?.accent ? (
                      <>{formik.errors.theme?.accent}</>
                    ) : null}
                  </FormErrorMessage>
                </FormControl>
              </Box>
            </Stack> */}

            <Stack direction="row" spacing={4} mt={6}>
              <Box flex="1">
                <FormControl
                  isInvalid={formik.touched.region && formik.errors.region}
                >
                  <CountryStateGenerator
                    defaultCity={singlecontact?.region}
                    onCityChange={(getCity) => {
                      formik.setFieldValue("region", getCity, false);
                    }}
                  />
                  <FormErrorMessage minHeight="20px">
                    {formik.touched.region && formik.errors.region ? (
                      <>{formik.errors.region}</>
                    ) : null}
                  </FormErrorMessage>
                </FormControl>
              </Box>
            </Stack>

            <FormControl
              isInvalid={
                formik.touched.orgRegistrationDetails &&
                formik.errors.orgRegistrationDetails
              }
              mt={6}
            >
              <FormLabel htmlFor="orgRegistrationDetails">Details</FormLabel>
              <Textarea
                id="orgRegistrationDetails"
                type="text"
                {...formik.getFieldProps("orgRegistrationDetails")}
              />
              <FormErrorMessage minHeight="20px">
                {formik.touched.orgRegistrationDetails &&
                formik.errors.orgRegistrationDetails ? (
                  <>{formik.errors.orgRegistrationDetails}</>
                ) : null}
              </FormErrorMessage>
            </FormControl>

            <Stack direction="row" spacing={8} mt={6}>
              <Button
                colorScheme="teal"
                type="submit"
                isLoading={false}
                size="md"
                width="200px"
              >
                Update
              </Button>
              <Button
                colorScheme="red"
                type="button"
                onClick={() => {
                  navigate(-1);
                }}
                isLoading={false}
                width="100px"
              >
                Cancel
              </Button>
            </Stack>
          </form>
        </Box>
      )}
    </Formik>
  );
};

export default EditOrg;
